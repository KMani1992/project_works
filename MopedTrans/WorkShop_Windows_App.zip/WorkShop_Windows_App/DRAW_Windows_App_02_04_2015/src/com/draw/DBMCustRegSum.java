package com.draw;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class DBMCustRegSum extends General{
	
	public static Boolean insertCustRegSum(GetSets set,int n,ArrayList<GetSets> data) {						
		try {			
			dbmConOpen();
			conn.setAutoCommit(false);
			PreparedStatement stmt=null;
			int i=0;
			Strsql="INSERT INTO `" + TRAN_QUALIFIER + "`.`custregistrationsumry`(`CustId`,`ordersubject`,`OrderDate`,`orddetsmry`,`OperId`,`nodeid`,`orddeliverydate`)" ;
			Strsql = Strsql + " VALUES(?,?,?,?,?,?,?)";
			stmt=conn.prepareStatement(Strsql);			
			stmt.setLong(1, set.getGen_CustId()); 
			stmt.setString(2, set.getCrm_ordersubject());
			stmt.setString(3, set.getCrm_OrderDate());
			stmt.setString(4, set.getCrm_orddetsmry());
			stmt.setLong(5, GetSets.getComm_OperId());
			stmt.setString(6, GetSets.getComm_NodeId());
			stmt.setString(7, set.getCrm_orddeliverydate());
			stmt.execute();
			
			int majid=getOrdMajId(set.getGen_CustId());			
			//System.out.println(data.toArray());
			//for (i=0;i<n;i++){
			for(GetSets gscr : data){				
				Strsql="INSERT INTO `" + TRAN_QUALIFIER + "`.`custregistration`(`CustId`,`OrderMajorId`,`OrderSubId`,`orderdetail`,`OrderDate`,`OperId`,`nodeid`,`orddeliverydate`)" ;
				Strsql = Strsql + " VALUES(?,?,?,?,?,?,?,?)";
				stmt=conn.prepareStatement(Strsql);				
				stmt.setLong(1, gscr.getGen_CustId());
				stmt.setLong(2, majid);
				stmt.setLong(3, ++i);
				stmt.setString(4, gscr.getCrm_orddetail());				
				stmt.setString(5, gscr.getCrm_OrderDate());
				stmt.setLong(6, GetSets.getComm_OperId());
				stmt.setString(7, GetSets.getComm_NodeId());
				stmt.setString(8, gscr.getCrm_orddeliverydate());
				stmt.execute();
			}
			conn.commit();
			return true;
		}catch (SQLException e) {
			// TODO Auto-generated catch block			
			General.ErrMsg=e.getMessage().toString();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				General.ErrMsg=e1.getMessage().toString();
			}
			e.printStackTrace();			
			return false;
		}finally{
			ConnectionManager.getInstance().closeConnection();
		}
		
	}
	public static Boolean updateCustRegSum(GetSets set,int n,String ordDet[],String ordCanc[]){								
		try {
			int i=0;
			dbmConOpen();
			conn.setAutoCommit(false);
			PreparedStatement stmt;
			Strsql="update `custregistrationsumry` set `ordersubject`=?,`OrderDate`=?,`orddetsmry`=?,`ordercancel`=?,`orddeliverydate`=?,`Last_Updated`=?,`OperId`=? where `CustId`=? and `OrderMajorId`=?" ;
			stmt=conn.prepareStatement(Strsql);			
			stmt.setString(1, set.getCrm_ordersubject());
			stmt.setString(2, set.getCrm_OrderDate());
			stmt.setString(3, set.getCrm_orddetsmry());
			stmt.setString(4, set.getCrm_ordercancel());
			stmt.setString(5, set.getCrm_orddeliverydate());			
			stmt.setDate(6, serv_Date);
			stmt.setLong(7, set.getGen_OperId());
			stmt.setLong(8, set.getGen_CustId());
			stmt.setLong(9, set.getGen_OrderMajorId());			
			stmt.executeQuery();
			
			Strsql="delete from custregistration where `CustId`=? and `OrderMajorId`=?";
			stmt=conn.prepareStatement(Strsql);
			stmt.setLong(1, set.getGen_CustId());
			stmt.setLong(2, set.getGen_OrderMajorId());
			stmt.executeQuery();
			
			int majid=getOrdMajId(set.getGen_CustId());
			
			for (i=0;i<n;i++){
				Strsql="INSERT INTO `custregistration`(`CustId`,`OrderMajorId`,`OrderSubId`,`orderdetail`,`OrderDate`,`ordercancel`,`OperId`)" ;
				Strsql = Strsql + " VALUES(?,?,?,?,?)";
				stmt=conn.prepareStatement(Strsql);				
				stmt.setLong(1, set.getGen_CustId());
				stmt.setLong(2, majid);
				stmt.setLong(3, i);
				stmt.setString(4, ordDet[i]);
				stmt.setString(5, set.getCrm_OrderDate());
				stmt.setString(6, ordCanc[i]);
				stmt.setLong(7, set.getGen_OperId());
				stmt.executeQuery();
			}
			conn.commit();			
			return true;
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return false;
		}finally{
			ConnectionManager.getInstance().closeConnection();
		}		
	}
	public static ArrayList<Object[]> viewCustReg(){
		ArrayList<Object[]> data=new ArrayList<Object[]>();
		dbmConOpen();		
		try {			
			Strsql ="select cs.custid,(select custname from custsignup c where c.custid=cr.custid) as custname,cr.OrderMajorId,cr.OrderSubId,cr.Orderdate,cr.orddeliverydate,";
			Strsql =Strsql + "\n cs.ordersubject,cr.orderdetail,cr.pbfinunfinflag from `" + TRAN_QUALIFIER + "`.custregistrationsumry cs";
			Strsql =Strsql +"\n left join `" + TRAN_QUALIFIER + "`.custregistration cr  on cs.OrderMajorId=cr.OrderMajorId where orderdetail!='';";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){
				//System.out.println("in s whi");
				Object[] row=new Object[]{rs.getInt(1),
						rs.getString(2),
						rs.getInt(3),
						rs.getInt(4),
						datefrmt(rs.getString(5).toString()),
						datefrmt(rs.getString(6).toString()),						
						rs.getString(7),												
						rs.getString(8),
						rs.getString(9).toString().equalsIgnoreCase("N") ? "NotAssigned" : rs.getString(9)};
				data.add(row);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "SubService Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}		
		return data;
		
	}
	public static ArrayList<String> dispCust(){
		ArrayList<String>  data=new ArrayList<String> ();
		dbmConOpen();		
		try {
			Strsql="select concat(`custname` ,' @',`CustId` ) as rate from `custsignup` where OnlineFlg='N' order by CustId;";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){		
				//System.out.println("a");
				data.add(rs.getString(1));
				//System.out.println("b");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "Service Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		//System.out.println(data.toString());
		return data;	
	}
	public static int getOrdMajId(int custid) {
		boolean flg;
		int majid;		
		//dbmConOpen();
		flg=false;
		majid=0;
		//Strsql="select userName,OperId from Operator where isnull(userName,'')=? and isnull(Password,'')=? and isnull(Active,'')='Y'";		
		Strsql="select max(OrdermajorId) as mid from `" + TRAN_QUALIFIER + "`.custregistrationsumry where `CustId`=? ";
		try {	
			///System.out.println(user);
			//System.out.println(Pass);
			ps =conn.prepareStatement(Strsql);			
			ps.setLong(1, custid);						
			rs =ps.executeQuery();	
			//System.out.println("1");
			while (rs.next()){
				majid=rs.getInt(1);				
				System.out.println(majid);
				//GetSets.setComm_NodeId(System.getenv("node-id"));
				flg=true;
				break;
			}
			//System.out.println("w22");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}finally{
			try {
				//System.out.println("w222");
				ps.clearBatch();
				ps.close();
				rs.close();
				//ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		//System.out.println("22");
		if(flg){
			return majid;			
		}else{
			return 0;
		}
			
		
	}
	private static String datefrmt(String dt){
		String dat;
		dat= dt.substring(8, 10) + "/" + dt.substring(5,7) + "/" + dt.substring(0,4);
		return dat;		
	}

}

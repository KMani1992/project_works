package com.draw;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JCheckBox;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

public class FrmCustSignUp extends JInternalFrame{
	
	/**
	 * Customer Sign Up
	 */
	private static final long serialVersionUID = 1L;
	private GridBagConstraints gbc;
	private JPanel btnPanel,panel,cntrlPanel;
	private JLabel lblheader,lblBottom;
	private JTextField txtCustName,txtMoBikeNo,txtMoBikeName,txtmobile,txtemail;
	private JCheckBox chkActive;	
	private int g_CustId;
	private JTable table;
	private JButton btnAdd,btnSave,btnEdit,btnCancel,btnClose,btnview;
	private enum Actbtn{
		Deflt,Add,Save,Edit,Cancel,View,Close}

	public FrmCustSignUp(){
		this.setTitle("Customer SignUp");
		this.setResizable(true);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setIconifiable(true);
		this.pack();
		prepareGUI();
		clr();
	}
	private void prepareGUI(){
		setLayout(new GridBagLayout());
		gbc=new GridBagConstraints();
		lblheader=new JLabel("Customer SignUp",JLabel.CENTER);
		lblheader.setFont(new Font("Verdana", Font.BOLD, 18));
		gbc.fill=GridBagConstraints.BOTH;
		addFrmComp(lblheader, 0, 0, 1,1,100,1);		
		cntrlPanel=new JPanel();
		
		addFrmComp(cntrlPanel, 0, 1,1,1, 100,1);
		btnPanel=new JPanel();
		btnPanel.setLayout(new FlowLayout());
		btnAdd=new JButton("Add");			
		btnCancel=new JButton("Cancel");				
		btnClose=new JButton("Close");
		btnEdit=new JButton("Edit");
		btnSave=new JButton("Save");
		btnview=new JButton("view");
		
		addBtnCons(btnAdd,'A',"Add");	
		addBtnCons(btnCancel,'C',"Cancel");
		addBtnCons(btnClose,'l',"Close");
		addBtnCons(btnEdit,'E',"Edit");
		addBtnCons(btnSave,'S',"Save");
		addBtnCons(btnview,'V',"View");
		
		btnPanel.add(btnAdd);
		btnPanel.add(btnSave);
		btnPanel.add(btnEdit);
		btnPanel.add(btnCancel);
		btnPanel.add(btnview);
		btnPanel.add(btnClose);
		
		addFrmComp(btnPanel, 0, 2,1,1, 100,1);
		
		table =new JTable();
		JScrollPane jsrl=new JScrollPane(table);
		addFrmComp(jsrl, 0, 3,1,1, 100,1);		
		lblBottom=new JLabel("Select Row and Press [E] For Edit.",JLabel.CENTER);
		lblBottom.setFont(new Font("Arial", Font.BOLD, 14));
		addFrmComp(lblBottom, 0, 4,1,1, 100,1);
		panel=new JPanel();
		panel.setLayout(new GridBagLayout());		
		cntrlPanel.add(panel);				
		txtCustName=new JTextField(20);
		txtMoBikeNo=new JTextField(20);
		txtMoBikeName=new JTextField(20);
		txtmobile=new JTextField(20);
		txtemail=new JTextField(20);
		chkActive=new JCheckBox();
		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("CustomerName : "), 0, 0, 1, 1, 100, 1);
		addCompCons(txtCustName, 1, 0, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("MotorBike No : "), 0, 1, 1, 1, 100, 1);
		addCompCons(txtMoBikeNo, 1, 1, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("MotorBike Name : "), 0, 2, 1, 1, 100, 1);
		addCompCons(txtMoBikeName, 1, 2, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("Mobile : "), 0, 3, 1, 1, 100, 1);
		addCompCons(txtmobile, 1, 3, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("EmailAddr : "), 0, 4, 1, 1, 100, 1);
		addCompCons(txtemail, 1, 4, 1, 1, 100, 1);		
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("Active : "), 0, 5, 1, 1, 100, 1);
		addCompCons(chkActive, 1, 5, 1, 1, 100, 1);
		table.addKeyListener(new actionListner());
		csuView();
		btnEnab(Actbtn.Deflt);
		clr();		
		btnAdd.requestFocus();		
	}
	private class actionListner implements ActionListener,KeyListener{
		public void actionPerformed(ActionEvent e){
			GetSets gs=new GetSets();
			if (e.getActionCommand().equalsIgnoreCase("Add")){
				cntEnabDisab(true);
				txtCustName.requestFocus();
				btnEnab(Actbtn.Add);
			}else if (e.getActionCommand().equalsIgnoreCase("Save")){
				if(txtCustName.getText().equalsIgnoreCase("")
						|| txtMoBikeName.getText().equalsIgnoreCase("")
						|| txtMoBikeNo.getText().equalsIgnoreCase("")
						|| txtmobile.getText().equalsIgnoreCase("")
						|| txtemail.getText().equalsIgnoreCase("")){				
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "ServiceMaster",JOptionPane.WARNING_MESSAGE);
					
				}else{
					gs.setCum_custname(txtCustName.getText().toString());
					gs.setCum_motbikeno(txtMoBikeNo.getText().toString());
					gs.setCum_motbikename(txtMoBikeName.getText().toString());
					gs.setCum_mobieno(txtmobile.getText().toString());
					gs.setCum_emailaddr(txtemail.getText().toString());
					gs.setGen_Active(chkActive.isSelected() ? "Y" : "N");
					if (DBMCustSignUp.insertCustSignUp(gs)) {
						JOptionPane.showMessageDialog(null, "Saved.",General.cmpTitle + "Customer SignUp",1);
						clr();
						csuView();
						btnEnab(Actbtn.Save);
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Saved.\n" + General.ErrMsg,General.cmpTitle + "Customer SignUp",0);
					}									
				}				
			}else if (e.getActionCommand().equalsIgnoreCase("Edit")){
				if(txtCustName.getText().equalsIgnoreCase("")
						|| txtMoBikeName.getText().equalsIgnoreCase("")
						|| txtMoBikeNo.getText().equalsIgnoreCase("")
						|| txtmobile.getText().equalsIgnoreCase("")
						|| txtemail.getText().equalsIgnoreCase("")){
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "Customer SignUp",JOptionPane.WARNING_MESSAGE);
					
				}else{
					//System.out.println(g_CustId);
					gs.setGen_CustId(g_CustId);
					gs.setCum_custname(txtCustName.getText().toString());
					gs.setCum_motbikeno(txtMoBikeNo.getText().toString());
					gs.setCum_motbikename(txtMoBikeName.getText().toString());
					gs.setCum_mobieno(txtmobile.getText().toString());
					gs.setCum_emailaddr(txtemail.getText().toString());
					gs.setGen_Active(chkActive.isSelected() ? "Y" : "N");
					if (DBMCustSignUp.updateCustSignUp(gs)) {
						JOptionPane.showMessageDialog(null, "Edited.",General.cmpTitle + "Customer SignUp",1);
						clr();
						csuView();
						btnEnab(Actbtn.Save);
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Edited.\n" + General.ErrMsg,General.cmpTitle + "ServiceMaster",0);
					}									
				}
			}else if (e.getActionCommand().equalsIgnoreCase("Cancel")){
				clr();
				btnEnab(Actbtn.Cancel);
			}else if (e.getActionCommand().equalsIgnoreCase("View")){
				csuView();
			}else if (e.getActionCommand().equalsIgnoreCase("Close")){
				dispose();
			}
		}
		public void keyTyped(KeyEvent e){
			
		}
		public void keyPressed(KeyEvent e){			
			if (e.getSource().equals(table)){				
				if (e.getKeyCode() == KeyEvent.VK_E){
					clr();
					cntEnabDisab(true);					
					int selrow=table.getSelectedRow();
					txtCustName.setText(table.getValueAt(selrow, 1).toString());
					txtMoBikeNo.setText(table.getValueAt(selrow, 2).toString());
					txtMoBikeName.setText(table.getValueAt(selrow, 3).toString());
					txtmobile.setText(table.getValueAt(selrow, 4).toString());
					txtemail.setText(table.getValueAt(selrow, 5).toString());
					chkActive.setSelected(table.getValueAt(selrow, 6).toString().equalsIgnoreCase("Y") ? true : false);
					g_CustId=Integer.parseInt(table.getValueAt(selrow, 0).toString());
					btnEnab(Actbtn.Edit);
					txtCustName.requestFocus();
				}
			}
		}
		public void keyReleased(KeyEvent e){
			
		}
	}
	public void clr(){
		txtCustName.setText("");
		txtemail.setText("");
		txtMoBikeName.setText("");
		txtMoBikeNo.setText("");
		txtmobile.setText("");
		chkActive.setSelected(true);		
		cntEnabDisab(false);
	}
	public void addCompCons(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		panel.add(cmp,gbc);
		
	}
	public void addFrmComp(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		add(cmp,gbc);
		
	}
	private void addBtnCons(JButton btn,Character mne,String actcmd){
		btn.addActionListener(new actionListner());
		btn.setActionCommand(actcmd);
		btn.setMnemonic(mne);
	}
	private void btnEnab(Actbtn btn){
		switch (btn){
		case Add:
			btnEnabDisab(false, true, false, true, false);
			break;
		case Save:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Edit:
			btnEnabDisab(false, false, true, true, false);
			break;
		case Cancel:
			btnEnabDisab(true, false, false, true, true);
			break;
		case View:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Deflt:
			btnEnabDisab(true, false, false, true, true);
			break;
		}
	}
	private void btnEnabDisab(Boolean btAdd,Boolean btSave,Boolean btEdit,Boolean btCancel,Boolean btView){
		btnAdd.setEnabled(btAdd);
		btnSave.setEnabled(btSave);
		btnEdit.setEnabled(btEdit);
		btnCancel.setEnabled(btCancel);
		btnview.setEnabled(btView);
	}
	private void cntEnabDisab(Boolean val){
		txtCustName.setEnabled(val);
		txtemail.setEnabled(val);
		txtMoBikeName.setEnabled(val);
		txtMoBikeNo.setEnabled(val);
		txtmobile.setEnabled(val);
		chkActive.setEnabled(val);		
	}
	private void csuView(){		
		String operClm[]={"CustId","CustomerName","MotorBikeNo","MotorBikeName","Mobile","E-MailAddr","Active"};
		ArrayList<Object[]> data=new ArrayList<Object[]>();				
		data=DBMCustSignUp.viewCustSignUp();				
		Object[][] realData=data.toArray(new Object[data.size()][]);				
		table.setBorder(new LineBorder(new Color(0,0,0)));
		table.setModel(new DefaultTableModel(realData,operClm){
			private static final long serialVersionUID = 1L;		
			public boolean isCellEditable(int row,int column){return false;}
		});
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);				
	}

}

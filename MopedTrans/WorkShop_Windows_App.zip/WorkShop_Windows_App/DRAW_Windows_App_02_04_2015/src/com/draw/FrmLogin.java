package com.draw;


import java.awt.Component;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class FrmLogin {
	private  JFrame frame;		
	private GridBagConstraints gbc;	
	private JLabel lblhdr;
	private JPanel contrlpan,panel;
	private JTextField txtUserName;
	private JPasswordField txtPassword;
	private FrmLogin(){
		prepareGUI();
	}
	
	private void prepareGUI(){
		frame=new JFrame("DRAW-Login");
		frame.setSize(500,300);		
		frame.setResizable(false);
		//frame.setExtendedState(JFrame.MAXIMIZED_BOTH);		
		frame.setLocationRelativeTo(null);		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		frame.setLayout(new GridLayout(2,1));
		
		contrlpan=new JPanel();
		contrlpan.setLayout(new FlowLayout());
		
		lblhdr = new JLabel("Login",JLabel.CENTER);
		lblhdr.setFont(new Font("Verdana", Font.BOLD, 24));
		
		frame.add(lblhdr);
		frame.add(contrlpan);
		frame.setVisible(true);		
	}
	
	public static void main(String args[]){
		FrmLogin login =new FrmLogin();		
		login.showLogin();
	}
	
	public void showLogin(){
		panel=new JPanel();
		panel.setLayout(new GridBagLayout());
		gbc=new GridBagConstraints();
		gbc.ipady=3;
		gbc.fill=GridBagConstraints.BOTH;
		addComponent(new JLabel("UserName :"), 0, 2, 1, 1,100,1);		
		gbc.ipadx=10;
		txtUserName=new JTextField(20);
		addComponent(txtUserName, 0,3, 1, 1,100,1);		
		
		gbc.fill=GridBagConstraints.BOTH;
		addComponent(new JLabel("Password :"), 1, 2, 1, 1,100,1);
		txtPassword=new JPasswordField(20);
		addComponent(txtPassword, 1, 3, 1, 1,100,1);
		
		JPanel btnpanel=new JPanel();
		btnpanel.setLayout(new FlowLayout());
		
		JButton btnlogin =new JButton("Login");
		JButton btncancel =new JButton("Cancel");
		
		btnlogin.setActionCommand("login");
		btnlogin.setMnemonic('l');
		btncancel.setActionCommand("cancel");
		btncancel.setMnemonic('C');
		
		btnlogin.addActionListener(new ButtonClickListener());
		btncancel.addActionListener(new ButtonClickListener());
		
		btnpanel.add(btnlogin);
		btnpanel.add(btncancel);
		
		gbc.fill=GridBagConstraints.BOTH;
		addComponent(btnpanel, 2, 3, 1, 1,100,1);
		
		contrlpan.add(panel);
		txtUserName.requestFocus();
		frame.setVisible(true);
	}
	private void addComponent(Component c, int row,int col,int width,int height,int wx,int wy){		
		gbc.gridx=col;
		gbc.gridy=row;
		gbc.gridwidth=width;
		gbc.gridheight=height;
		gbc.weightx=wx;
		gbc.weighty=wy;
		panel.add(c,gbc);
	}
	private class ButtonClickListener implements ActionListener{
		@SuppressWarnings("deprecation")
		public void actionPerformed (ActionEvent e){
			String cmd=e.getActionCommand();
			if( cmd.equalsIgnoreCase("login")){
				if (txtUserName.getText().toString().equalsIgnoreCase("") || txtPassword.getText().toString().equalsIgnoreCase("") ){
					JOptionPane.showMessageDialog(null, "Login Failed! \nPlease Enter UserName and Password.", "DRAW-Login", 0);
					
				}else{					
					if(DBMLogin.isLogin(txtUserName.getText().toString() ,txtPassword.getText().toString())){
						frame.hide();
						FrmMain frmmain=new FrmMain();
						frmmain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						frmmain.setExtendedState(JFrame.MAXIMIZED_BOTH);
						frmmain.setVisible(true);					
					}else{
						JOptionPane.showMessageDialog(null, "Login Failed! \nPlease Check UserName and Password.", "DRAW-Login", 0);
						txtPassword.setText("");					
					}
				}
				
			
			}else if (cmd.equalsIgnoreCase("cancel")){
				System.exit(0);
			}
		}
	}

}

package com.draw;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;


public class FrmCustRegStatus extends JInternalFrame{
	
	/**
	 * Customer Registration Status Updation
	 */
	private static final long serialVersionUID = 1L;
	private JLabel lblHeadr,lblBottom;
	private JPanel cntrlPanel,btnPanel,panel;	
	private GridBagConstraints gbc;
	private JTextField txtRemarks;
	private JCheckBox chkOvChkFlg;
	private JComboBox<String> cboCust,cboTrnId,cboOrdMajId;
	private JSpinner spnBattery,spnEnging,spnSuspension,spnBrake,spnExteri,spnTyres,
	spnElec,spnSeats,spnOveral;
	private int G_SerTranId;
	private JTable table;
	private JButton btnAdd,btnSave,btnEdit,btnCancel,btnClose,btnview;
	private enum Actbtn{
		Deflt,Add,Save,Edit,Cancel,View,Close}

	public FrmCustRegStatus(){
		this.setTitle("Customer Registration Status Updation");
		this.setResizable(true);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setIconifiable(true);
		//this.pack();
		prepareGUI();
		DispCust();		
		clr();
	}
	public void prepareGUI(){
		setLayout(new GridBagLayout());
		gbc=new GridBagConstraints();
		lblHeadr=new JLabel("Customer Registration Status Updation",JLabel.CENTER);
		lblHeadr.setFont(new Font("Verdana", Font.BOLD, 18));
		gbc.fill=GridBagConstraints.BOTH;
		addFrmComp(lblHeadr, 0, 0, 1,1,100,1);		
		cntrlPanel=new JPanel();
		
		addFrmComp(cntrlPanel, 0, 1,1,1, 100,1);
		btnPanel=new JPanel();
		btnPanel.setLayout(new FlowLayout());
		btnAdd=new JButton("Add");			
		btnCancel=new JButton("Cancel");				
		btnClose=new JButton("Close");
		btnEdit=new JButton("Edit");
		btnSave=new JButton("Save");
		btnview=new JButton("view");
		
		addBtnCons(btnAdd,'A',"Add");	
		addBtnCons(btnCancel,'C',"Cancel");
		addBtnCons(btnClose,'l',"Close");
		addBtnCons(btnEdit,'E',"Edit");
		addBtnCons(btnSave,'S',"Save");
		addBtnCons(btnview,'V',"View");
		
		btnPanel.add(btnAdd);
		btnPanel.add(btnSave);
		btnPanel.add(btnEdit);
		btnPanel.add(btnCancel);
		btnPanel.add(btnview);
		btnPanel.add(btnClose);
		
		addFrmComp(btnPanel, 0, 2,1,1, 100,1);
		
		table =new JTable();
		JScrollPane jsrl=new JScrollPane(table);
		addFrmComp(jsrl, 0, 3,1,1, 100,1);		
		lblBottom=new JLabel("Select Row and Press [E] For Edit.",JLabel.CENTER);
		lblBottom.setFont(new Font("Arial", Font.BOLD, 14));
		addFrmComp(lblBottom, 0, 4,1,1, 100,1);
		panel=new JPanel();
		panel.setLayout(new GridBagLayout());		
		cntrlPanel.add(panel);		
		
		cboCust=new JComboBox<String>();
		cboTrnId=new JComboBox<String>();
		cboOrdMajId=new JComboBox<String>();
		cboCust.addActionListener(new actionListner());
		cboOrdMajId.addActionListener(new actionListner());
		cboCust.setActionCommand("cbocust");
		cboOrdMajId.setActionCommand("cboOrdMid");	
		
		spnBattery=new JSpinner(new SpinnerNumberModel(0,0,100,1));
		spnEnging=new JSpinner(new SpinnerNumberModel(0,0,100,1));
		spnSuspension=new JSpinner(new SpinnerNumberModel(0,0,100,1));
		spnBrake=new JSpinner(new SpinnerNumberModel(0,0,100,1));
		spnExteri=new JSpinner(new SpinnerNumberModel(0,0,100,1));
		spnTyres=new JSpinner(new SpinnerNumberModel(0,0,100,1));
		spnElec=new JSpinner(new SpinnerNumberModel(0,0,100,1));
		spnSeats=new JSpinner(new SpinnerNumberModel(0,0,100,1));
		spnOveral=new JSpinner(new SpinnerNumberModel(0,0,100,1));
		
		txtRemarks=new JTextField(20);
		chkOvChkFlg=new JCheckBox();
		Calendar cal =Calendar.getInstance();
		cal.setTime(new Date());
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		
		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Customer : "), 0, 0, 1, 1, 100, 1);
		addCompCons(cboCust, 1, 0, 1, 1, 100, 1);		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		//gbc.ipadx=20;		
		addCompCons(new JLabel("TranDate : "), 2, 0, 1, 1, 100, 1);
		addCompCons(new JLabel(sdf.format(cal.getTime())), 3, 0, 1, 1, 100, 1);
				
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("ServiceTranId : "), 0, 1, 1, 1, 100, 1);
		addCompCons(cboTrnId, 1, 1, 1, 1, 100, 1);		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("OrderMajorId : "), 2, 1, 1, 1, 100, 1);
		addCompCons(cboOrdMajId, 3, 1, 1, 1, 100, 1);
		
		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Battery : "), 0, 2, 1, 1, 100, 1);
		addCompCons(spnBattery, 1, 2, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Engine : "), 2, 2, 1, 1, 100, 1);
		addCompCons(spnEnging, 3, 2, 1, 1, 100, 1);
		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Suspension : "), 0, 3, 1, 1, 100, 1);
		addCompCons(spnSuspension, 1, 3, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Brakes : "), 2, 3, 1, 1, 100, 1);
		addCompCons(spnBrake, 3, 3, 1, 1, 100, 1);
		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Exterior : "), 0, 4, 1, 1, 100, 1);
		addCompCons(spnExteri, 1, 4, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Tyres : "), 2, 4, 1, 1, 100, 1);
		addCompCons(spnTyres, 3, 4, 1, 1, 100, 1);
		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Electrical : "), 0, 5, 1, 1, 100, 1);
		addCompCons(spnElec, 1, 5, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Seats : "), 2, 5, 1, 1, 100, 1);
		addCompCons(spnSeats, 3, 5, 1, 1, 100, 1);
		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Overal : "), 0, 6, 1, 1, 100, 1);
		addCompCons(spnOveral, 1, 6, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("OveralChkFlag : "), 2, 6, 1, 1, 100, 1);
		addCompCons(chkOvChkFlg, 3, 6, 1, 1, 100, 1);
		
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("Remarks : "), 0, 7, 1, 1, 100, 1);		
		addCompCons(txtRemarks, 1, 7, 3, 1, 100, 1);
		
		
		table.addKeyListener(new actionListner());
		crsView();
		btnEnab(Actbtn.Deflt);
		clr();
		btnAdd.requestFocus();					
	}
	private class actionListner implements ActionListener,KeyListener{
		public void actionPerformed(ActionEvent e){
			GetSets gs=new GetSets();
			if (e.getActionCommand().equalsIgnoreCase("Add")){
				cntEnabDisab(true);
				cboCust.requestFocus();
				btnEnab(Actbtn.Add);
			}else if (e.getActionCommand().equalsIgnoreCase("Save")){
				if(txtRemarks.getText().equalsIgnoreCase("")){
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "Customer Registration Status Updation",JOptionPane.WARNING_MESSAGE);
					
				}else{
					String Custname=cboCust.getItemAt(cboCust.getSelectedIndex());
					gs.setGen_CustId(Integer.parseInt(Custname.substring(Custname.indexOf("@")+1).toString()));					
					gs.setGen_OrderMajorId(Integer.parseInt(cboOrdMajId.getItemAt(cboOrdMajId.getSelectedIndex()).toString()));
					gs.setGen_SerTranid(Integer.parseInt(cboTrnId.getItemAt(cboTrnId.getSelectedIndex()).toString()));
					gs.setCrs_battery(Integer.parseInt(spnBattery.getValue().toString()));
					gs.setCrs_engine(Integer.parseInt(spnEnging.getValue().toString()));
					gs.setCrs_suspension(Integer.parseInt(spnSuspension.getValue().toString()));
					gs.setCrs_breaks(Integer.parseInt(spnBrake.getValue().toString()));
					gs.setCrs_exterior(Integer.parseInt(spnExteri.getValue().toString()));
					gs.setCrs_tyres(Integer.parseInt(spnTyres.getValue().toString()));
					gs.setCrs_electrical(Integer.parseInt(spnElec.getValue().toString()));
					gs.setCrs_seats(Integer.parseInt(spnSeats.getValue().toString()));
					gs.setCrs_overal(Integer.parseInt(spnOveral.getValue().toString()));					
					gs.setCrs_remarks(txtRemarks.getText().toString());					
					gs.setCrs_OveralChFlag(chkOvChkFlg.isSelected() ? "Y" : "N");
					if (DBMCustRegStatus.insertCustRegStatus(gs)) {
						JOptionPane.showMessageDialog(null, "Saved.",General.cmpTitle + "Customer Registration Status Updation",1);
						clr();
						crsView();
						btnEnab(Actbtn.Save);
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Saved.\n" + General.ErrMsg,General.cmpTitle + "Customer Registration Status Updation",0);
					}									
				}				
			}else if (e.getActionCommand().equalsIgnoreCase("Edit")){
				if(txtRemarks.getText().equalsIgnoreCase("")){
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "Customer Registration Status Updation",JOptionPane.WARNING_MESSAGE);
					
				}else{
					gs.setGen_SerStatusId(G_SerTranId);
					String Custname=cboCust.getItemAt(cboCust.getSelectedIndex());
					gs.setGen_CustId(Integer.parseInt(Custname.substring(Custname.indexOf("@")+1).toString()));					
					gs.setGen_OrderMajorId(Integer.parseInt(cboOrdMajId.getItemAt(cboOrdMajId.getSelectedIndex()).toString()));
					gs.setGen_SerTranid(Integer.parseInt(cboTrnId.getItemAt(cboTrnId.getSelectedIndex()).toString()));
					gs.setCrs_battery(Integer.parseInt(spnBattery.getValue().toString()));
					gs.setCrs_engine(Integer.parseInt(spnEnging.getValue().toString()));
					gs.setCrs_suspension(Integer.parseInt(spnSuspension.getValue().toString()));
					gs.setCrs_breaks(Integer.parseInt(spnBrake.getValue().toString()));
					gs.setCrs_exterior(Integer.parseInt(spnExteri.getValue().toString()));
					gs.setCrs_tyres(Integer.parseInt(spnTyres.getValue().toString()));
					gs.setCrs_electrical(Integer.parseInt(spnElec.getValue().toString()));
					gs.setCrs_seats(Integer.parseInt(spnSeats.getValue().toString()));
					gs.setCrs_overal(Integer.parseInt(spnOveral.getValue().toString()));
					gs.setCrs_remarks(txtRemarks.getText().toString());					
					gs.setCrs_OveralChFlag(chkOvChkFlg.isSelected() ? "Y" : "N");
					if (DBMCustRegStatus.updateCustRegStatus(gs)) {
						JOptionPane.showMessageDialog(null, "Edited.",General.cmpTitle + "Customer Registration Status Updation",1);
						clr();
						crsView();
						btnEnab(Actbtn.Save);
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Edited.\n" + General.ErrMsg,General.cmpTitle + "Customer Registration Status Updation",0);
					}									
				}
			}else if (e.getActionCommand().equalsIgnoreCase("Cancel")){
				clr();
				btnEnab(Actbtn.Cancel);
			}else if (e.getActionCommand().equalsIgnoreCase("View")){
				crsView();
			}else if (e.getActionCommand().equalsIgnoreCase("Close")){
				dispose();
			}else if (e.getActionCommand().equalsIgnoreCase("cboCust")){
				String cust=cboCust.getItemAt(cboCust.getSelectedIndex());
				DispOrMid(Integer.parseInt(cust.substring(cust.indexOf("@")+1).toString()));
				if (cboOrdMajId.getItemCount() > 0){cboOrdMajId.setSelectedIndex(0);}
				cboOrdMajId.requestFocus();
			}else if (e.getActionCommand().equalsIgnoreCase("cboOrdMid")){
				String ord=cboOrdMajId.getItemAt(cboOrdMajId.getSelectedIndex());
				DispStranId(Integer.parseInt(ord.toString()));
				if (cboTrnId.getItemCount() > 0){cboTrnId.setSelectedIndex(0);}
				cboTrnId.requestFocus();
			}
		}
		public void keyTyped(KeyEvent e){
			
		}
		public void keyPressed(KeyEvent e){			
			if (e.getSource().equals(table)){				
				if (e.getKeyCode() == KeyEvent.VK_E){
					clr();
					cntEnabDisab(true);					
					int selrow=table.getSelectedRow();
					int i;
					String CustName=table.getValueAt(selrow, 3).toString() + " @" + table.getValueAt(selrow, 2).toString();					
					for (i=0 ;i < cboCust.getItemCount() ; i++){
						if(cboCust.getItemAt(i).equalsIgnoreCase(CustName)){
							cboCust.setSelectedIndex(i);
							break;
						}
					}
					String ordMid=table.getValueAt(selrow, 6).toString();					
					cboOrdMajId.addItem(ordMid);					
					String strid=table.getValueAt(selrow, 4).toString();					
					cboTrnId.addItem(strid);					
					spnBattery.setValue(Integer.parseInt(table.getValueAt(selrow, 7).toString()));
					spnEnging.setValue(Integer.parseInt(table.getValueAt(selrow, 8).toString()));
					spnSuspension.setValue(Integer.parseInt(table.getValueAt(selrow, 9).toString()));
					spnBrake.setValue(Integer.parseInt(table.getValueAt(selrow, 10).toString()));
					spnExteri.setValue(Integer.parseInt(table.getValueAt(selrow, 11).toString()));
					spnTyres.setValue(Integer.parseInt(table.getValueAt(selrow, 12).toString()));
					spnElec.setValue(Integer.parseInt(table.getValueAt(selrow, 13).toString()));
					spnSeats.setValue(Integer.parseInt(table.getValueAt(selrow, 14).toString()));					
					spnOveral.setValue(Integer.parseInt(table.getValueAt(selrow, 15).toString()));					
					txtRemarks.setText(table.getValueAt(selrow, 16).toString());
					chkOvChkFlg.setSelected(table.getValueAt(selrow, 5).toString().equalsIgnoreCase("Y") ? true : false);
					G_SerTranId=Integer.parseInt(table.getValueAt(selrow, 0).toString());
					btnEnab(Actbtn.Edit);
					cboCust.requestFocus();
				}
			}
		}
		public void keyReleased(KeyEvent e){
			
		}
	}
	public void clr(){
		/*if (cboCust.getItemCount() > 0){cboCust.setSelectedIndex(0);}
		if (cboOrdMajId.getItemCount() > 0){cboOrdMajId.setSelectedIndex(0);}
		if (cboTrnId.getItemCount() > 0){cboTrnId.setSelectedIndex(0);}*/
		spnBattery.setValue(0);
		spnBrake.setValue(0);
		spnElec.setValue(0);
		spnEnging.setValue(0);
		spnExteri.setValue(0);
		spnOveral.setValue(0);
		spnSeats.setValue(0);
		spnSuspension.setValue(0);
		spnTyres.setValue(0);
		txtRemarks.setText("");
		chkOvChkFlg.setSelected(true);
		cntEnabDisab(false);
	}
	public void addCompCons(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		panel.add(cmp,gbc);
		
	}
	public void addFrmComp(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		add(cmp,gbc);
		
	}
	private void addBtnCons(JButton btn,Character mne,String actcmd){
		btn.addActionListener(new actionListner());
		btn.setActionCommand(actcmd);
		btn.setMnemonic(mne);
	}
	private void btnEnab(Actbtn btn){
		switch (btn){
		case Add:
			btnEnabDisab(false, true, false, true, false);
			break;
		case Save:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Edit:
			btnEnabDisab(false, false, true, true, false);
			break;
		case Cancel:
			btnEnabDisab(true, false, false, true, true);
			break;
		case View:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Deflt:
			btnEnabDisab(true, false, false, true, true);
			break;
		}
	}
	private void btnEnabDisab(Boolean btAdd,Boolean btSave,Boolean btEdit,Boolean btCancel,Boolean btView){
		btnAdd.setEnabled(btAdd);
		btnSave.setEnabled(btSave);
		btnEdit.setEnabled(btEdit);
		btnCancel.setEnabled(btCancel);
		btnview.setEnabled(btView);
	}
	private void cntEnabDisab(Boolean val){
		spnBattery.setEnabled(val);
		spnBrake.setEnabled(val);
		spnElec.setEnabled(val);
		spnEnging.setEnabled(val);
		spnExteri.setEnabled(val);
		spnOveral.setEnabled(val);
		spnSeats.setEnabled(val);
		spnSuspension.setEnabled(val);
		spnTyres.setEnabled(val);
		cboCust.setEnabled(val);
		cboOrdMajId.setEnabled(val);
		cboTrnId.setEnabled(val);
		txtRemarks.setEnabled(val);		
		chkOvChkFlg.setEnabled(val);
	}
	private void crsView(){		
		String operClm[]={"CustRegStatusId","TranDate","CustId","CustName","ServiceTranId","OveralChkFlag","OrderMajorId","Battery","Engine","Suspension","Brakes","Exterior","Tyres","Electrical","Seats","Overal","Remarks"};
		ArrayList<Object[]> data=new ArrayList<Object[]>();				
		data=DBMCustRegStatus.viewCrSt();				
		Object[][] realData=data.toArray(new Object[data.size()][]);				
		table.setBorder(new LineBorder(new Color(0,0,0)));
		table.setModel(new DefaultTableModel(realData,operClm){
			private static final long serialVersionUID = 1L;		
			public boolean isCellEditable(int row,int column){return false;}
		});
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);				
	}
	private void DispCust(){
		ArrayList<String> data=new ArrayList<String>();
		data=DBMCustRegStatus.dispCust();		
		for(String el : data){
			cboCust.addItem(el.toString());
		}		
	}
	private void DispOrMid(int custId){
		ArrayList<String> data=new ArrayList<String>();
		data=DBMCustRegStatus.dispOrder(custId);
		cboOrdMajId.removeAllItems();
		for(String el : data){
			cboOrdMajId.addItem(el.toString());
		}		
	}
	private void DispStranId(int ordmId){
		ArrayList<String> data=new ArrayList<String>();
		data=DBMCustRegStatus.dispSTranId(ordmId);
		cboTrnId.removeAllItems();
		for(String el : data){
			cboTrnId.addItem(el.toString());
		}		
	}

}

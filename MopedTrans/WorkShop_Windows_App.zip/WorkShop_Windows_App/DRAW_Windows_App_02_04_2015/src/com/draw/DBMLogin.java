package com.draw;


import java.sql.SQLException;

public class DBMLogin extends General {
	public static Boolean isLogin(String user,String Pass) {
		boolean flg;		
		dbmConOpen();
		flg=false;
		//Strsql="select userName,OperId from Operator where isnull(userName,'')=? and isnull(Password,'')=? and isnull(Active,'')='Y'";		
		Strsql="select userName,OperId from Operator where `userName`=? and `Password`=? and `Active`='Y'";
		try {	
			///System.out.println(user);
			//System.out.println(Pass);
			ps =conn.prepareStatement(Strsql);			
			ps.setString(1, user);			
			ps.setString(2, Pass);			
			rs =ps.executeQuery();	
			//System.out.println("1");
			while (rs.next()){
				//System.out.println("2");
				GetSets.setComm_OperId(rs.getInt(2));
				//System.out.println(GetSets.getComm_OperId());
				GetSets.setComm_NodeId(System.getenv("node-id"));
				flg=true;
				break;
			}
			//System.out.println("w22");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}finally{
			try {
				//System.out.println("w222");
				ps.clearBatch();
				ps.close();
				rs.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		//System.out.println("22");
		if(flg){
			return true;			
		}else{
			return false;
		}
			
		
	}
}

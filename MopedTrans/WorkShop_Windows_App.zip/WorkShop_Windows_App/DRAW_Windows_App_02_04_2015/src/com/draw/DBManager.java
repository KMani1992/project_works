package com.draw;

public class DBManager extends General{
	
}


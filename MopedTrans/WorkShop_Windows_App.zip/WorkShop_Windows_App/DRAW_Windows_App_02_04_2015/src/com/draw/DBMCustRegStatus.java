package com.draw;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class DBMCustRegStatus extends General {
	
	public static Boolean insertCustRegStatus(GetSets set) {						
		try {			
			dbmConOpen();
			Strsql="INSERT INTO `" + TRAN_QUALIFIER + "`.`custregstatus` (`CustId`,`SerTranId`,`OveralChFlag`,`OrderMajorId`,";
			Strsql = Strsql + " `OperId`,`battery`,`engine`,`suspension`,`brakes`,`exterior`,`tyres`,";
			Strsql = Strsql + " `electrical`,`seats`,`overal`,`Remarks`,`nodeid`)";
			Strsql = Strsql + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement stmt=conn.prepareStatement(Strsql);			
			stmt.setLong(1, set.getGen_CustId());
			stmt.setLong(2, set.getGen_SerTranid());
			stmt.setString(3, set.getCrs_OveralChFlag());
			stmt.setLong(4, set.getGen_OrderMajorId());
			stmt.setLong(5, GetSets.getComm_OperId());
			stmt.setLong(6, set.getCrs_battery());
			stmt.setLong(7, set.getCrs_engine());
			stmt.setLong(8, set.getCrs_suspension());
			stmt.setLong(9, set.getCrs_breaks());
			stmt.setLong(10, set.getCrs_exterior());
			stmt.setLong(11, set.getCrs_tyres());
			stmt.setLong(12, set.getCrs_electrical());
			stmt.setLong(13, set.getCrs_seats());
			stmt.setLong(14, set.getCrs_overal());
			stmt.setString(15, set.getCrs_remarks());
			stmt.setString(16, GetSets.getComm_NodeId());
			stmt.execute();
			return true;
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			General.ErrMsg=e.getMessage().toString();
			return false;
		}finally{
			ConnectionManager.getInstance().closeConnection();
		}
		
	}
	public static Boolean updateCustRegStatus(GetSets set){								
		try {
			dbmConOpen();
			Strsql="update `" + TRAN_QUALIFIER + "`.`custregstatus` set `SerTranId`=?,`OveralChFlag`=?,`OrderMajorId`=?,";
			Strsql = Strsql + " `OperId`=?,`battery`=?,`engine`=?,`suspension`=?,`brakes`=?,`exterior`=?,`tyres`=?,";
			Strsql = Strsql + " `electrical`=?,`seats`=?,`overal`=?,`Remarks`=?,`nodeid`=? where `CustId`=? and CrStId=?";		
						
			PreparedStatement stmt=conn.prepareStatement(Strsql);			
			stmt.setLong(1, set.getGen_SerTranid());
			stmt.setString(2, set.getCrs_OveralChFlag());
			stmt.setLong(3, set.getGen_OrderMajorId());
			stmt.setLong(4, GetSets.getComm_OperId());
			stmt.setLong(5, set.getCrs_battery());
			stmt.setLong(6, set.getCrs_engine());
			stmt.setLong(7, set.getCrs_suspension());
			stmt.setLong(8, set.getCrs_breaks());
			stmt.setLong(9, set.getCrs_exterior());
			stmt.setLong(10, set.getCrs_tyres());
			stmt.setLong(11, set.getCrs_electrical());
			stmt.setLong(12, set.getCrs_seats());
			stmt.setLong(13, set.getCrs_overal());
			stmt.setString(14, set.getCrs_remarks());
			stmt.setString(15, GetSets.getComm_NodeId());
			stmt.setLong(16, set.getGen_CustId());			
			stmt.setLong(17, set.getGen_SerStatusId());			
			stmt.execute();			
			return true;
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			General.ErrMsg=e.getMessage().toString();
			return false;
		}finally{
			ConnectionManager.getInstance().closeConnection();
		}		
	}	
	
	public static ArrayList<Object[]> viewCrSt(){
		ArrayList<Object[]> data=new ArrayList<Object[]>();
		dbmConOpen();		
		try {
			System.out.println("ins");
			Strsql ="select s.CrStId,s.updated,s.CustId,(select custname from custsignup c where c.custid=s.custid) as custname,s.SerTranId,s.OveralChFlag,";
			Strsql =Strsql + "\n s.OrderMajorId,s.battery,s.engine,s.suspension,s.brakes,s.exterior,s.tyres,s.electrical,s.seats,s.overal,";
			Strsql =Strsql + "\n s.Remarks from `" + TRAN_QUALIFIER + "`.custregstatus s ";
			Strsql =Strsql +"\n order by s.CrStId;";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){
				//System.out.println("in s whi");
				Object[] row=new Object[]{rs.getInt(1),
						datefrmt(rs.getString(2).toString()),
						rs.getInt(3),
						rs.getString(4),
						rs.getInt(5),
						rs.getString(6),
						rs.getInt(7),
						rs.getInt(8),
						rs.getInt(9),
						rs.getInt(10),
						rs.getInt(11),
						rs.getInt(12),
						rs.getInt(13),
						rs.getInt(14),
						rs.getInt(15),
						rs.getInt(16),
						rs.getString(17)};
				data.add(row);
			}			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "SubService Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}		
		return data;
		
	}
	private static String datefrmt(String dt){
		String dat;
		dat= dt.substring(8, 10) + "/" + dt.substring(5,7) + "/" + dt.substring(0,4);
		return dat;		
	}
	public static ArrayList<String> dispOrder(int custid){
		ArrayList<String>  data=new ArrayList<String> ();
		dbmConOpen();		
		try {
			Strsql="select concat(OrderMajorId,'') as  OrderMajorId from `" + TRAN_QUALIFIER + "`.custregistration where CustId=" + custid + " order by OrderMajorId;";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){		
				//System.out.println("a");
				data.add(rs.getString(1));
				//System.out.println("b");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "SubService Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		//System.out.println(data.toString());
		return data;
	}
	public static ArrayList<String> dispCust(){
		ArrayList<String>  data=new ArrayList<String> ();
		dbmConOpen();		
		try {
			Strsql="select concat(`custname` ,' @',`CustId` ) as rate from `custsignup` where OnlineFlg='N' order by CustId;";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){		
				//System.out.println("a");
				data.add(rs.getString(1));
				//System.out.println("b");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "Service Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		//System.out.println(data.toString());
		return data;	
	}
	
	public static ArrayList<String> dispSTranId(int ord){
		ArrayList<String>  data=new ArrayList<String> ();
		dbmConOpen();		
		try {
			Strsql="select concat(`SerTranId` ,'') as tranid from `" + TRAN_QUALIFIER + "`.`servicetran` where OrderMajorId=" + ord + " order by SerTranId;";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){		
				//System.out.println("a");
				data.add(rs.getString(1));
				//System.out.println("b");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "Service Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		//System.out.println(data.toString());
		return data;	
	}

}

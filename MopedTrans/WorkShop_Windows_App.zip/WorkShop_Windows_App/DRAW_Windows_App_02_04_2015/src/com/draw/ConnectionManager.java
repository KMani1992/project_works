package com.draw;
import java.sql.*;
public class ConnectionManager extends General   {
	
	private static ConnectionManager instance=null;
	private static String USERNAME="root";
	private static String PASSWORD="root";
	private static String CONN_STR="jdbc:mysql://localhost/" + MAST_QUALIFIER;
	private Connection conn=null;
	
	private ConnectionManager(){		
	}
	
	public static ConnectionManager getInstance(){
		if (instance ==null){
			instance =new ConnectionManager();
		}
		return instance;
	}
	private Boolean openConnection(){
		try {
			conn=DriverManager.getConnection(CONN_STR,USERNAME, PASSWORD);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} 
		return true;
	}
	
	public Connection getConnection(){
		if (openConnection()){
			System.out.println("Connection Opened");
			return conn;
		}else{
			return null;
		}
			
	}
	public void closeConnection(){
		try {
			conn.close();
			System.out.println("Connection Closed");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

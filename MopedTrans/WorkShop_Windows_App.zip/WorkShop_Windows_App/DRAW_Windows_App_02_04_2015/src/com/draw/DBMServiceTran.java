package com.draw;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class DBMServiceTran extends General {
	
	public static Boolean insertServiceTran(ArrayList<GetSets> data) {						
		try {			
			dbmConOpen();
			conn.setAutoCommit(false);
			int majid=getSTranMajId();
			for(GetSets gscr : data){
				Strsql="INSERT INTO `" + TRAN_QUALIFIER + "`.`servicetran`(`SerTranId`,`SerTrandate`,`CustId`,`OrderMajorId`,`OrderSubId`,`ServId`,`SubServId`,`OperId`,`Remarks`,`nodeid`)" ;
				Strsql = Strsql + " VALUES(?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement stmt=conn.prepareStatement(Strsql);
				stmt.setLong(1, majid);
				stmt.setString(2, gscr.getStn_Trandate());
				stmt.setLong(3, gscr.getGen_CustId());
				stmt.setLong(4, gscr.getGen_OrderMajorId());
				stmt.setLong(5, gscr.getGen_OrderSubId());
				stmt.setLong(6, gscr.getGen_ServId());
				stmt.setLong(7, gscr.getGen_SubServId());
				stmt.setLong(8, GetSets.getComm_OperId());
				stmt.setString(9, gscr.getStn_Remarks());
				stmt.setString(10, GetSets.getComm_NodeId());
				stmt.execute();
				
				Strsql="update `" + TRAN_QUALIFIER + "`.`custregistration` set `pbfinunfinflag`=? where `CustId`=? and `OrderMajorId`=? and `OrderSubId`=?" ;
				PreparedStatement stmtU=conn.prepareStatement(Strsql);
				stmtU.setString(1, "Y");
				stmtU.setLong(2, gscr.getGen_CustId());
				stmtU.setLong(3, gscr.getGen_OrderMajorId());
				stmtU.setLong(4, gscr.getGen_OrderSubId());
				stmtU.execute();
			}
			conn.commit();
			return true;
		}catch (SQLException e) {
			General.ErrMsg=e.getMessage().toString();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				General.ErrMsg=e1.getMessage().toString();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			return false;
		}finally{
			ConnectionManager.getInstance().closeConnection();
		}
		
	}
	public static Boolean updateServiceTran(GetSets set){								
		try {
			dbmConOpen();
			Strsql="update `servicetran` set `SerTrandate`=?,`CustId`=?,`Cancel`=?,`OperId`=?,`Last_Updated`=? where `SerTranId`=? and `OrderMajorId`=? and `OrderSubId`=?" ;
			PreparedStatement stmt=conn.prepareStatement(Strsql);			
			stmt.setDate(1, serv_Date);
			stmt.setLong(2, set.getGen_CustId());			
			stmt.setString(3, set.getStn_Cancel());
			stmt.setLong(4, set.getGen_OperId());			
			stmt.setDate(5, serv_Date);
			stmt.setLong(6, set.getGen_SerTranid());
			stmt.setLong(7, set.getGen_OrderMajorId());
			stmt.setLong(8, set.getGen_OrderSubId());
			stmt.executeQuery();			
			return true;
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}finally{
			ConnectionManager.getInstance().closeConnection();
		}		
	}
	public static ArrayList<Object[]> viewServiceTran(){
		ArrayList<Object[]> data=new ArrayList<Object[]>();
		dbmConOpen();		
		try {			
			Strsql ="select s.SerTranId,s.SerTranDate,s.CustId,(select custname from custsignup c where c.custid=s.custid) as custname,s.OrderMajorId,s.OrderSubId,";
			Strsql =Strsql + "\n s.ServId,(select  ServiceName from servicemast sm where sm.ServId=s.ServId) as servName,s.SubServId,(select  SubServiceName from subservicemast sum where sum.ServId=s.ServId and sum.SubServId=s.SubServId) as subServName,";
			Strsql =Strsql + "\n s.Remarks from `" + TRAN_QUALIFIER + "`.servicetran s";
			Strsql =Strsql +"\n order by s.SerTranId;";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){
				//System.out.println("in s whi");
				Object[] row=new Object[]{rs.getInt(1),
						datefrmt(rs.getString(2).toString()),
						rs.getInt(3),
						rs.getString(4),
						rs.getInt(5),
						rs.getInt(6),
						rs.getInt(7),
						rs.getString(8),
						rs.getInt(9),
						rs.getString(10),
						rs.getString(11)};
				data.add(row);
			}			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "SubService Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}		
		return data;
		
	}
	public static ArrayList<String> dispCust(){
		ArrayList<String>  data=new ArrayList<String> ();
		dbmConOpen();		
		try {
			Strsql="select concat(`custname` ,' @',`CustId` ) as rate from `custsignup` where OnlineFlg='N' order by CustId;";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){		
				//System.out.println("a");
				data.add(rs.getString(1));
				//System.out.println("b");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "Service Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		//System.out.println(data.toString());
		return data;	
	}
	public static int getSTranMajId() {
		boolean flg;
		int majid;		
		//dbmConOpen();
		flg=false;
		majid=0;
		//Strsql="select userName,OperId from Operator where isnull(userName,'')=? and isnull(Password,'')=? and isnull(Active,'')='Y'";		
		Strsql="select max(SerTranId) as mstid from `" + TRAN_QUALIFIER + "`.servicetran";
		try {	
			///System.out.println(user);
			//System.out.println(Pass);
			ps =conn.prepareStatement(Strsql);									
			rs =ps.executeQuery();	
			//System.out.println("1");
			while (rs.next()){
				majid=rs.getInt(1);
				majid +=1;
				//System.out.println(majid);
				//GetSets.setComm_NodeId(System.getenv("node-id"));
				flg=true;
				break;
			}
			//System.out.println("w22");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}finally{
			try {
				//System.out.println("w222");
				ps.clearBatch();
				ps.close();
				rs.close();
				//ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		//System.out.println("22");
		if(flg){
			return majid;			
		}else{
			return 0;
		}
			
		
	}
	private static String datefrmt(String dt){
		String dat;
		dat= dt.substring(8, 10) + "/" + dt.substring(5,7) + "/" + dt.substring(0,4);
		return dat;		
	}
	
	public static ArrayList<String> dispService(){
		ArrayList<String>  data=new ArrayList<String> ();
		dbmConOpen();		
		try {
			Strsql="select concat(`ServiceName` ,' @',`ServId` ) as Service from servicemast order by ServId";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){		
				//System.out.println("a");
				data.add(rs.getString(1));
				//System.out.println("b");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "SubService Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		//System.out.println(data.toString());
		return data;
	}
	
	public static ArrayList<String> dispSubService(int srvid){
		ArrayList<String>  data=new ArrayList<String> ();
		dbmConOpen();		
		try {
			Strsql="select concat(`SubServiceName` ,' @',`SubServId` ) as SubService from subservicemast where ServId in(select ServId from servicemast where ServId=" + srvid + ") order by ServId,SubServId";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){		
				//System.out.println("a");
				data.add(rs.getString(1));
				//System.out.println("b");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "SubService Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		//System.out.println(data.toString());
		return data;
	}
	public static ArrayList<String> dispOrder(){
		ArrayList<String>  data=new ArrayList<String> ();
		dbmConOpen();		
		try {
			Strsql="select concat(OrderMajorId,'') as  OrderMajorId from `" + TRAN_QUALIFIER + "`.custregistration where pbfinunfinflag='N' order by OrderMajorId;";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){		
				//System.out.println("a");
				data.add(rs.getString(1));
				//System.out.println("b");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "SubService Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		//System.out.println(data.toString());
		return data;
	}
	
	public static ArrayList<String> dispSubOrd(int ordmId){
		ArrayList<String>  data=new ArrayList<String> ();
		dbmConOpen();		
		try {
			Strsql="select concat(`OrderSubId` ,'') as OrdSubId from `" + TRAN_QUALIFIER + "`.custregistration where pbfinunfinflag='N' and OrderMajorId=" + ordmId + " order by OrderMajorId,OrderSubId;";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){		
				//System.out.println("a");
				data.add(rs.getString(1));
				//System.out.println("b");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "SubService Master", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		//System.out.println(data.toString());
		return data;
	}

}

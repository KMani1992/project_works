package com.draw;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

public class FrmRateMaster extends JInternalFrame {
	/**
	 * Rate Master
	 */
	private static final long serialVersionUID = 1L;
	private JLabel lblHeadr,lblBottom;
	private JPanel cntrlPanel,btnPanel,panel;	
	private GridBagConstraints gbc;
	private JTextField txtRate;
	private JCheckBox chkActive;
	private int G_rateId;
	private JTable table;
	private JButton btnAdd,btnSave,btnEdit,btnCancel,btnClose,btnview;
	private enum Actbtn{
		Deflt,Add,Save,Edit,Cancel,View,Close}

	public FrmRateMaster(){
		this.setTitle("Rate Master");
		this.setResizable(true);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setIconifiable(true);
		//this.pack();
		prepareGUI();
		clr();
	}
	public void prepareGUI(){
		setLayout(new GridBagLayout());
		gbc=new GridBagConstraints();
		lblHeadr=new JLabel("Rate Master",JLabel.CENTER);
		lblHeadr.setFont(new Font("Verdana", Font.BOLD, 18));
		gbc.fill=GridBagConstraints.BOTH;
		addFrmComp(lblHeadr, 0, 0, 1,1,100,1);		
		cntrlPanel=new JPanel();
		
		addFrmComp(cntrlPanel, 0, 1,1,1, 100,1);
		btnPanel=new JPanel();
		btnPanel.setLayout(new FlowLayout());
		btnAdd=new JButton("Add");			
		btnCancel=new JButton("Cancel");				
		btnClose=new JButton("Close");
		btnEdit=new JButton("Edit");
		btnSave=new JButton("Save");
		btnview=new JButton("view");
		
		addBtnCons(btnAdd,'A',"Add");	
		addBtnCons(btnCancel,'C',"Cancel");
		addBtnCons(btnClose,'l',"Close");
		addBtnCons(btnEdit,'E',"Edit");
		addBtnCons(btnSave,'S',"Save");
		addBtnCons(btnview,'V',"View");
		
		btnPanel.add(btnAdd);
		btnPanel.add(btnSave);
		btnPanel.add(btnEdit);
		btnPanel.add(btnCancel);
		btnPanel.add(btnview);
		btnPanel.add(btnClose);
		
		addFrmComp(btnPanel, 0, 2,1,1, 100,1);
		
		table =new JTable();
		JScrollPane jsrl=new JScrollPane(table);
		addFrmComp(jsrl, 0, 3,1,1, 100,1);		
		lblBottom=new JLabel("Select Row and Press [E] For Edit.",JLabel.CENTER);
		lblBottom.setFont(new Font("Arial", Font.BOLD, 14));
		addFrmComp(lblBottom, 0, 4,1,1, 100,1);
		panel=new JPanel();
		panel.setLayout(new GridBagLayout());		
		cntrlPanel.add(panel);				
		txtRate=new JTextField(20);
		chkActive=new JCheckBox();
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Rate"), 0, 0, 1, 1, 100, 1);
		addCompCons(txtRate, 1, 0, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Active"), 0, 1, 1, 1, 100, 1);
		addCompCons(chkActive, 1, 1, 1, 1, 100, 1);
		table.addKeyListener(new actionListner());
		rcrView();
		btnEnab(Actbtn.Deflt);
		clr();
		btnAdd.requestFocus();					
	}
	private class actionListner implements ActionListener,KeyListener{
		public void actionPerformed(ActionEvent e){
			GetSets gs=new GetSets();
			if (e.getActionCommand().equalsIgnoreCase("Add")){
				cntEnabDisab(true);
				txtRate.requestFocus();
				btnEnab(Actbtn.Add);
			}else if (e.getActionCommand().equalsIgnoreCase("Save")){
				if(txtRate.getText().equalsIgnoreCase("")){
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "RateMaster",JOptionPane.WARNING_MESSAGE);
					
				}else{
					gs.setRatem_Rate(Double.parseDouble(txtRate.getText().toString()));					
					gs.setGen_Active(chkActive.isSelected() ? "Y" : "N");
					if (DBMRateMaster.insertRateMaster(gs)) {
						JOptionPane.showMessageDialog(null, "Saved.",General.cmpTitle + "RateMaster",1);
						clr();
						rcrView();
						btnEnab(Actbtn.Save);
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Saved.\n" + General.ErrMsg,General.cmpTitle + "RateMaster",0);
					}									
				}				
			}else if (e.getActionCommand().equalsIgnoreCase("Edit")){
				if(txtRate.getText().equalsIgnoreCase("")){
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "RateMaster",JOptionPane.WARNING_MESSAGE);
					
				}else{
					gs.setGen_RateId(G_rateId);
					gs.setRatem_Rate(Double.parseDouble(txtRate.getText().toString()));					
					gs.setGen_Active(chkActive.isSelected() ? "Y" : "N");
					if (DBMRateMaster.updateRateMaster(gs)) {
						JOptionPane.showMessageDialog(null, "Edited.",General.cmpTitle + "RateMaster",1);
						clr();
						rcrView();
						btnEnab(Actbtn.Save);
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Edited.\n" + General.ErrMsg,General.cmpTitle + "RateMaster",0);
					}									
				}
			}else if (e.getActionCommand().equalsIgnoreCase("Cancel")){
				clr();
				btnEnab(Actbtn.Cancel);
			}else if (e.getActionCommand().equalsIgnoreCase("View")){
				rcrView();
			}else if (e.getActionCommand().equalsIgnoreCase("Close")){
				dispose();
			}
		}
		public void keyTyped(KeyEvent e){
			
		}
		public void keyPressed(KeyEvent e){			
			if (e.getSource().equals(table)){				
				if (e.getKeyCode() == KeyEvent.VK_E){
					clr();
					cntEnabDisab(true);					
					int selrow=table.getSelectedRow();
					txtRate.setText(table.getValueAt(selrow, 1).toString());
					chkActive.setSelected(table.getValueAt(selrow, 2).toString().equalsIgnoreCase("Y") ? true : false);
					G_rateId=Integer.parseInt(table.getValueAt(selrow, 0).toString());
					btnEnab(Actbtn.Edit);
					txtRate.requestFocus();
				}
			}
		}
		public void keyReleased(KeyEvent e){
			
		}
	}
	public void clr(){
		txtRate.setText("");
		chkActive.setSelected(true);
		cntEnabDisab(false);
	}
	public void addCompCons(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		panel.add(cmp,gbc);
		
	}
	public void addFrmComp(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		add(cmp,gbc);
		
	}
	private void addBtnCons(JButton btn,Character mne,String actcmd){
		btn.addActionListener(new actionListner());
		btn.setActionCommand(actcmd);
		btn.setMnemonic(mne);
	}
	private void btnEnab(Actbtn btn){
		switch (btn){
		case Add:
			btnEnabDisab(false, true, false, true, false);
			break;
		case Save:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Edit:
			btnEnabDisab(false, false, true, true, false);
			break;
		case Cancel:
			btnEnabDisab(true, false, false, true, true);
			break;
		case View:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Deflt:
			btnEnabDisab(true, false, false, true, true);
			break;
		}
	}
	private void btnEnabDisab(Boolean btAdd,Boolean btSave,Boolean btEdit,Boolean btCancel,Boolean btView){
		btnAdd.setEnabled(btAdd);
		btnSave.setEnabled(btSave);
		btnEdit.setEnabled(btEdit);
		btnCancel.setEnabled(btCancel);
		btnview.setEnabled(btView);
	}
	private void cntEnabDisab(Boolean val){
		txtRate.setEnabled(val);		
		chkActive.setEnabled(val);
	}
	private void rcrView(){		
		String operClm[]={"RateId","Rate","Active"};
		ArrayList<Object[]> data=new ArrayList<Object[]>();				
		data=DBMRateMaster.viewRate();				
		Object[][] realData=data.toArray(new Object[data.size()][]);				
		table.setBorder(new LineBorder(new Color(0,0,0)));
		table.setModel(new DefaultTableModel(realData,operClm){
			private static final long serialVersionUID = 1L;		
			public boolean isCellEditable(int row,int column){return false;}
		});
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);				
	}

}

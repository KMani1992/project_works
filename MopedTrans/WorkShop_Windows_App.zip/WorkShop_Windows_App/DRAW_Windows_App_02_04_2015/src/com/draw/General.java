package com.draw;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

public class General {
	public static String MAST_QUALIFIER="DRAWMAINDB";
	public static String TRAN_QUALIFIER="DRAWTRANDB";
	public static String DB_OWNER=".";	
	public static String Strsql;
	public static String ErrMsg;
	public static final String cmpTitle="DRAW-";
	public static Connection conn=null;
	public static Date serv_Date;
	public static Statement stmt=null;
	public static ResultSet rs=null;
	public Statement nsstmt=null;
	public ResultSet nsrs=null;
	public static PreparedStatement ps=null;	
	public static void dbmConOpen(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=ConnectionManager.getInstance().getConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}		
	}
	public General(){
		//dbmConOpen();
		//stmt=(Statement) conn.createStatement();
		//Strsql="show databases LIKE 'company';";
		//rs=stmt.executeQuery(Strsql);		
	}
	
}

package com.draw;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;


public class FrmCustRegSum extends JInternalFrame {
	/**
	 * Customer Service Registration
	 */
	private static final long serialVersionUID = 1L;
	private GridBagConstraints gbc;
	private JPanel btnPanel,panel,cntrlPanel,addPanel;
	private JLabel lblheader,lblBottom,lbldate;
	private JTextField txtNoFDelvDays,txtOrdSub,txtOrdDet;
	private JComboBox<String> cboCustomer;	
	private int g_rId;
	private JTable table;
	private JButton btnAdd,btnAddtoGrid,btnAddCancel,btnSave,btnCancel,btnView,btnClose,btnEditGrid;
	private enum Actbtn{
		Deflt,Add,Save,Edit,Cancel,View,Close}
	private DefaultTableModel modl;
	
	public FrmCustRegSum(){
		this.setTitle("Service Registration");
		this.pack();
		this.setResizable(true);
		this.setMaximizable(true);		
		this.setClosable(true);
		this.setIconifiable(true);
		prepareGUI();
		DispCust();
		clr(true);
	}
	private void prepareGUI(){
		setLayout(new GridBagLayout());
		gbc=new GridBagConstraints();
		GregorianCalendar c=new GregorianCalendar();
		lblheader=new JLabel("Customer Service Registration",JLabel.CENTER);
		lblheader.setFont(new Font("Verdana", Font.BOLD, 18));
		gbc.fill=GridBagConstraints.BOTH;
		addFrmComp(lblheader, 0, 0, 1,1,100,1);		
		cntrlPanel=new JPanel();
		
		addFrmComp(cntrlPanel, 0, 1,1,1, 100,1);
		btnPanel=new JPanel();
		btnPanel.setLayout(new FlowLayout());
		addPanel=new JPanel();
		addPanel.setLayout(new FlowLayout());
		btnAdd=new JButton("Add");			
		btnCancel=new JButton("Cancel");
		btnView=new JButton("View");
		btnClose=new JButton("Close");	
		btnSave=new JButton("Save");
		btnAddtoGrid=new JButton("AddToGrid");
		btnAddCancel=new JButton("Clear");
		btnEditGrid=new JButton("EditGrid");
		
		addBtnCons(btnAdd,'A',"Add");	
		addBtnCons(btnCancel,'C',"Cancel");
		addBtnCons(btnView,'V',"View");
		addBtnCons(btnClose,'l',"Close");		
		addBtnCons(btnSave,'S',"Save");		
		addBtnCons(btnAddtoGrid,'G',"AddToGrid");
		addBtnCons(btnEditGrid,'E',"EditGrid");
		addBtnCons(btnAddCancel,'r',"Clear");
				
		btnPanel.add(btnAdd);
		btnPanel.add(btnSave);		
		btnPanel.add(btnCancel);
		btnPanel.add(btnView);
		btnPanel.add(btnClose);
		
		addPanel.add(btnAddtoGrid);
		addPanel.add(btnEditGrid);
		addPanel.add(btnAddCancel);
		
		addFrmComp(addPanel, 0, 2,1,1, 100,1);
		
		table =new JTable();
		
		//table.setAutoCreateColumnsFromModel(false);
		
		JScrollPane jsrl=new JScrollPane(table);
		addFrmComp(jsrl, 0, 3,1,1, 100,1);				
		
		addFrmComp(btnPanel, 0, 4,1,1, 100,1);
		lblBottom=new JLabel("Select Row and Press [E] For Edit, Press [R] For Remove, Press [C] For Cancel.",JLabel.CENTER);
		lblBottom.setFont(new Font("Arial", Font.BOLD, 14));
		addFrmComp(lblBottom, 0, 5,1,1, 100,1);
		panel=new JPanel();
		panel.setLayout(new GridBagLayout());		
		cntrlPanel.add(panel);
		cboCustomer=new JComboBox<String>();
		lbldate=new JLabel(c.get(Calendar.DATE) + "/"+ c.get(Calendar.MONTH) + "/" + c.get(Calendar.YEAR),JLabel.LEFT);
		txtNoFDelvDays=new JTextField(10);
		txtOrdSub=new JTextField(30);
		txtOrdDet=new JTextField(40);
		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Customer : "), 0, 0, 1, 1, 100, 1);
		addCompCons(cboCustomer, 1, 0, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("OrderDate : "), 0, 1, 1, 1, 100, 1);
		addCompCons(lbldate, 1, 1, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("NoOfDeliveryDays : "), 0, 2, 1, 1, 100, 1);
		addCompCons(txtNoFDelvDays, 1, 2, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("OrderSubject : "), 0, 3, 1, 1, 100, 1);
		addCompCons(txtOrdSub, 1, 3, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("OrderDetail : "), 0, 4, 1, 1, 100, 1);
		addCompCons(txtOrdDet, 1, 4, 1, 1, 100, 1);
		
		table.addKeyListener(new actionListner());
		csuView();
		btnEnab(Actbtn.Deflt);
		clr(true);	
		cntEnabDisab(false);
		btnAdd.requestFocus();		
	}
	private class actionListner implements ActionListener,KeyListener{
		public void actionPerformed(ActionEvent e){
			GetSets gs=new GetSets();
			if (e.getActionCommand().equalsIgnoreCase("Add")){
				cntEnabDisab(true);
				String operClm[]={"CustId","CustomerName","OrderDate","NoOfDelvDays","DeliveryDate","OrderSubject","OrderDetail"};		
				ArrayList<Object[]> data=new ArrayList<Object[]>();						
				Object[][] realData=data.toArray(new Object[data.size()][]);				
				table.setModel(new DefaultTableModel(realData, operClm){
					private static final long serialVersionUID = 1L;		
					public boolean isCellEditable(int row,int column){return false;}
				});
				modl=(DefaultTableModel) table.getModel();
				cboCustomer.requestFocus();
				btnEnab(Actbtn.Add);
			}else if (e.getActionCommand().equalsIgnoreCase("Save")){
				if(table.getRowCount() ==0){				
					JOptionPane.showMessageDialog(null, "Table Is Empty.",General.cmpTitle + "Customer Service Registration",JOptionPane.WARNING_MESSAGE);
					
				}else{
					ArrayList<GetSets> data=new ArrayList<GetSets>();
					//String operClm[]={"CustId","CustomerName","OrderDate","NoOfDelvDays","DeliveryDate","OrderSubject","OrderDetail"};
					System.out.println(modl.getRowCount());
					System.out.println(Integer.parseInt(modl.getValueAt(0, 0).toString()));
					Calendar cal=Calendar.getInstance();
					cal.setTime(new Date());
					SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");					
					//System.out.println(sdf.format(cal.getTime()));					
					System.out.println("Test");
					for(int r=0;r<modl.getRowCount();r++){
						GetSets gsar=new GetSets();
						gsar.setGen_CustId(Integer.parseInt(modl.getValueAt(r, 0).toString()));
						cal.setTime(new Date());						
						cal.add(Calendar.DAY_OF_MONTH, Integer.parseInt(modl.getValueAt(r, 3).toString()));						
						gsar.setCrm_orddeliverydate(sdf.format(cal.getTime()));
						gsar.setCrm_OrderDate(sdf.format(cal.getTime()));
						gsar.setCrm_ordersubject(modl.getValueAt(r, 5).toString());						
						gsar.setCrm_orddetail(modl.getValueAt(r, 6).toString());						
						data.add(gsar);
					}
					cal.setTime(new Date());
					gs.setGen_CustId(Integer.parseInt(modl.getValueAt(0, 0).toString()));
					gs.setCrm_OrderDate(sdf.format(cal.getTime()));
					gs.setCrm_ordersubject(modl.getValueAt(0, 5).toString());
					gs.setCrm_orddetsmry(modl.getValueAt(0, 6).toString());
					
					System.out.println("Test1");
					if (DBMCustRegSum.insertCustRegSum(gs,modl.getRowCount(),data)) {
						JOptionPane.showMessageDialog(null, "Saved.",General.cmpTitle + "Customer Service Registration",1);
						clr(true);
						csuView();
						btnEnab(Actbtn.Save);
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Saved.\n" + General.ErrMsg,General.cmpTitle + "Customer Service Registration",0);
					}									
				}				
			}else if (e.getActionCommand().equalsIgnoreCase("Edit")){
				
			}else if (e.getActionCommand().equalsIgnoreCase("Cancel")){
				clr(true);
				String operClm[]={"CustId","CustomerName","OrderDate","NoOfDelvDays","DeliveryDate","OrderSubject","OrderDetail"};		
				ArrayList<Object[]> data=new ArrayList<Object[]>();						
				Object[][] realData=data.toArray(new Object[data.size()][]);				
				table.setModel(new DefaultTableModel(realData, operClm));
				btnEnab(Actbtn.Cancel);
			}else if (e.getActionCommand().equalsIgnoreCase("View")){
				csuView();				
			}else if (e.getActionCommand().equalsIgnoreCase("AddToGrid")){
				if(txtNoFDelvDays.getText().equalsIgnoreCase("")
						|| txtOrdDet.getText().equalsIgnoreCase("")
						|| txtOrdSub.getText().equalsIgnoreCase("")){				
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "Customer Service Registration",JOptionPane.WARNING_MESSAGE);
					
				}else{
				csrAddtoGrid();				
				txtOrdDet.setText("");
				txtOrdDet.requestFocus();
				}
			}else if (e.getActionCommand().equalsIgnoreCase("Clear")){
				clr(false);
				g_rId=-1;
				btnAddtoGrid.setEnabled(true);
				btnEditGrid.setEnabled(false);
			}else if (e.getActionCommand().equalsIgnoreCase("EditGrid")){
				if(txtNoFDelvDays.getText().equalsIgnoreCase("")
						|| txtOrdDet.getText().equalsIgnoreCase("")
						|| txtOrdSub.getText().equalsIgnoreCase("")){				
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "Customer Service Registration",JOptionPane.WARNING_MESSAGE);
					
				}else{
					if (g_rId>=0){						
						String Custname=cboCustomer.getItemAt(cboCustomer.getSelectedIndex());
						Calendar cal=Calendar.getInstance();
						cal.setTime(new Date());
						cal.add(Calendar.DAY_OF_MONTH, Integer.parseInt(txtNoFDelvDays.getText().toString()));
						SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");				
						table.setValueAt(Custname.substring(Custname.indexOf("@")+1), g_rId, 0);				
						table.setValueAt(Custname.substring(0, Custname.indexOf("@")), g_rId, 1);				
						table.setValueAt(txtNoFDelvDays.getText().toString(), g_rId, 3);
						table.setValueAt(sdf.format(cal.getTime()), g_rId, 4);
						table.setValueAt(txtOrdSub.getText().toString(), g_rId, 5);
						table.setValueAt(txtOrdDet.getText().toString(), g_rId, 6);				
						clr(false);
						btnAddtoGrid.setEnabled(true);
						btnEditGrid.setEnabled(false);
						cboCustomer.requestFocus();
						g_rId=-1;
					}
				}
			}else if (e.getActionCommand().equalsIgnoreCase("Close")){
				dispose();
			}
		}
		public void keyTyped(KeyEvent e){
			
		}
		public void keyPressed(KeyEvent e){			
			if (e.getSource().equals(table)){				
				if (e.getKeyCode() == KeyEvent.VK_E && btnSave.isEnabled()){
					clr(true);
					cntEnabDisab(true);					
					int selrow=table.getSelectedRow();
					g_rId=selrow;
					//g_CustId=Integer.parseInt(table.getValueAt(selrow, 0).toString());
					String CustName=table.getValueAt(selrow, 1).toString() + " @" + table.getValueAt(selrow, 0).toString();
					int i;
					for (i=0 ;i < cboCustomer.getItemCount() ; i++){
						if(cboCustomer.getItemAt(i).equalsIgnoreCase(CustName)){
							cboCustomer.setSelectedIndex(i);
							break;
						}
					}
					txtNoFDelvDays.setText(table.getValueAt(selrow, 3).toString());
					txtOrdSub.setText(table.getValueAt(selrow, 5).toString());
					txtOrdDet.setText(table.getValueAt(selrow, 6).toString());
					cboCustomer.requestFocus();
					btnAddtoGrid.setEnabled(false);
					btnEditGrid.setEnabled(true);
					//btnEnab(Actbtn.Edit);					
				}else if (e.getKeyCode() == KeyEvent.VK_R && btnSave.isEnabled()){
					if(table.getRowCount() ==0){
						JOptionPane.showMessageDialog(null, "Table Is Empty.",General.cmpTitle + "Customer Service Registration",JOptionPane.WARNING_MESSAGE);						
					}else if(g_rId==table.getSelectedRow()){
						JOptionPane.showMessageDialog(null, "You Selected Row is in Edit Mode., Please Click ClearButton and Continue.",General.cmpTitle + "Customer Service Registration",JOptionPane.WARNING_MESSAGE);						
					}else{					
						int retout=JOptionPane.showConfirmDialog(null,"Confirm To Remove?",General.cmpTitle + "Customer Service Registration",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
						if (retout==JOptionPane.YES_OPTION){
							int selrow=table.getSelectedRow();
							modl.removeRow(selrow);
						}
					}
				}
			}
		}
		public void keyReleased(KeyEvent e){
			
		}
	}
	public void clr(Boolean enab){
		if (cboCustomer.getItemCount() > 0){cboCustomer.setSelectedIndex(0);}
		txtNoFDelvDays.setText("");
		txtOrdDet.setText("");
		txtOrdSub.setText("");				
		if (enab) {cntEnabDisab(false);}		
		btnEditGrid.setEnabled(false);
		g_rId=-1;
	}
	public void addCompCons(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		panel.add(cmp,gbc);
		
	}
	public void addFrmComp(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		add(cmp,gbc);
		
	}
	private void addBtnCons(JButton btn,Character mne,String actcmd){
		btn.addActionListener(new actionListner());
		btn.setActionCommand(actcmd);
		btn.setMnemonic(mne);
	}
	private void btnEnab(Actbtn btn){
		switch (btn){
		case Add:
			btnEnabDisab(false, true, false, true, false);
			break;
		case Save:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Edit:
			btnEnabDisab(false, false, true, true, false);
			break;
		case Cancel:
			btnEnabDisab(true, false, false, true, true);
			table.removeAll();
			break;
		case View:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Deflt:
			btnEnabDisab(true, false, false, true, true);
			break;
		}
	}
	private void btnEnabDisab(Boolean btAdd,Boolean btSave,Boolean btEdit,Boolean btCancel,Boolean btView){
		btnAdd.setEnabled(btAdd);
		btnSave.setEnabled(btSave);		
		btnCancel.setEnabled(btCancel);
		btnView.setEnabled(btView);
	}
	private void cntEnabDisab(Boolean val){
		cboCustomer.setEnabled(val);
		txtNoFDelvDays.setEnabled(val);
		txtOrdDet.setEnabled(val);
		txtOrdSub.setEnabled(val);
		btnAddtoGrid.setEnabled(val);
		btnAddCancel.setEnabled(val);
		//btnEditGrid.setEnabled(val);
	}
	private void csrAddtoGrid(){								
		
		table.setBorder(new LineBorder(new Color(0,0,0)));			
		String Custname=cboCustomer.getItemAt(cboCustomer.getSelectedIndex());
		Calendar cal=Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DAY_OF_MONTH, Integer.parseInt(txtNoFDelvDays.getText().toString()));
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");		
		Object[] realdate=new Object[]{Custname.substring(Custname.indexOf("@")+1),Custname.substring(0, Custname.indexOf("@")),lbldate.getText().toString(),txtNoFDelvDays.getText().toString(),sdf.format(cal.getTime()),txtOrdSub.getText().toString(),txtOrdDet.getText().toString()};	
		modl.addRow(realdate);
		//modl.isCellEditable(row, column)
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		
	}
	private void csuView(){		
		String operClm[]={"CustId","CustomerName","OrderMajorId","OrderSubId","OrderDate","DeliveryDate","OrderSubject","OrderDetail","FinUnFinFlag"};
		ArrayList<Object[]> data=new ArrayList<Object[]>();				
		data=DBMCustRegSum.viewCustReg();				
		Object[][] realData=data.toArray(new Object[data.size()][]);				
		table.setBorder(new LineBorder(new Color(0,0,0)));
		table.setModel(new DefaultTableModel(realData,operClm){
			private static final long serialVersionUID = 1L;		
			public boolean isCellEditable(int row,int column){return false;}
		});
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);				
	}
	private void DispCust(){
		ArrayList<String> data=new ArrayList<String>();
		data=DBMCustRegSum.dispCust();		
		for(String el : data){
			cboCustomer.addItem(el.toString());
		}		
	}

}

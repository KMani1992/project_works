package com.draw;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;


public class FrmServiceTran extends JInternalFrame {
	/**
	 * Service Transaction
	 */
	private static final long serialVersionUID = 1L;
	private GridBagConstraints gbc;
	private JPanel btnPanel,panel,cntrlPanel,addPanel;
	private JLabel lblheader,lblBottom,lbldate;
	private JTextField txtRemarks;
	private JComboBox<String> cboCustomer,cboordMid,cboOrdSid,cboSerId,cboSerSId;	
	private int g_rId;
	private JTable table;
	private JButton btnAdd,btnAddtoGrid,btnAddCancel,btnSave,btnCancel,btnView,btnClose,btnEditGrid;
	private enum Actbtn{
		Deflt,Add,Save,Edit,Cancel,View,Close}
	private DefaultTableModel modl;
	
	public FrmServiceTran(){
		this.setTitle("Service Transaction");
		this.pack();
		this.setResizable(true);
		this.setMaximizable(true);		
		this.setClosable(true);
		this.setIconifiable(true);
		prepareGUI();
		DispCust();
		DispOrMid();
		DispSerId();
		clr(true);
	}
	private void prepareGUI(){
		setLayout(new GridBagLayout());
		gbc=new GridBagConstraints();
		GregorianCalendar c=new GregorianCalendar();
		lblheader=new JLabel("Service Transaction",JLabel.CENTER);
		lblheader.setFont(new Font("Verdana", Font.BOLD, 18));
		gbc.fill=GridBagConstraints.BOTH;
		addFrmComp(lblheader, 0, 0, 1,1,100,1);		
		cntrlPanel=new JPanel();
		
		addFrmComp(cntrlPanel, 0, 1,1,1, 100,1);
		btnPanel=new JPanel();
		btnPanel.setLayout(new FlowLayout());
		addPanel=new JPanel();
		addPanel.setLayout(new FlowLayout());
		btnAdd=new JButton("Add");			
		btnCancel=new JButton("Cancel");
		btnView=new JButton("View");
		btnClose=new JButton("Close");	
		btnSave=new JButton("Save");
		btnAddtoGrid=new JButton("AddToGrid");
		btnAddCancel=new JButton("Clear");
		btnEditGrid=new JButton("EditGrid");
		
		addBtnCons(btnAdd,'A',"Add");	
		addBtnCons(btnCancel,'C',"Cancel");
		addBtnCons(btnView,'V',"View");
		addBtnCons(btnClose,'l',"Close");		
		addBtnCons(btnSave,'S',"Save");		
		addBtnCons(btnAddtoGrid,'G',"AddToGrid");
		addBtnCons(btnEditGrid,'E',"EditGrid");
		addBtnCons(btnAddCancel,'r',"Clear");
				
		btnPanel.add(btnAdd);
		btnPanel.add(btnSave);		
		btnPanel.add(btnCancel);
		btnPanel.add(btnView);
		btnPanel.add(btnClose);
		
		addPanel.add(btnAddtoGrid);
		addPanel.add(btnEditGrid);
		addPanel.add(btnAddCancel);
		
		addFrmComp(addPanel, 0, 2,1,1, 100,1);
		
		table =new JTable();
		
		//table.setAutoCreateColumnsFromModel(false);
		
		JScrollPane jsrl=new JScrollPane(table);
		addFrmComp(jsrl, 0, 3,1,1, 100,1);				
		
		addFrmComp(btnPanel, 0, 4,1,1, 100,1);
		lblBottom=new JLabel("Select Row and Press [E] For Edit, Press [R] For Remove, Press [C] For Cancel.",JLabel.CENTER);
		lblBottom.setFont(new Font("Arial", Font.BOLD, 14));
		addFrmComp(lblBottom, 0, 5,1,1, 100,1);
		panel=new JPanel();
		panel.setLayout(new GridBagLayout());		
		cntrlPanel.add(panel);
		cboCustomer=new JComboBox<String>();
		lbldate=new JLabel(c.get(Calendar.DATE) + "/"+ c.get(Calendar.MONTH) + "/" + c.get(Calendar.YEAR),JLabel.LEFT);
		cboordMid=new JComboBox<String>();
		cboOrdSid=new JComboBox<String>();
		cboSerId=new JComboBox<String>();
		cboSerSId=new JComboBox<String>();
		txtRemarks=new JTextField(30);
		cboordMid.addActionListener(new actionListner());
		cboSerId.addActionListener(new actionListner());
		cboordMid.setActionCommand("cboOrdMajId");
		cboSerId.setActionCommand("cboSerId");
		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("Customer : "), 0, 0, 1, 1, 100, 1);
		addCompCons(cboCustomer, 1, 0, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("OrderDate : "), 0, 1, 1, 1, 100, 1);
		addCompCons(lbldate, 1, 1, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("OrderMajorId : "), 0, 2, 1, 1, 100, 1);
		addCompCons(cboordMid, 1, 2, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("OrderSubId : "), 0, 3, 1, 1, 100, 1);
		addCompCons(cboOrdSid, 1, 3, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("ServiceName : "), 0, 4, 1, 1, 100, 1);
		addCompCons(cboSerId, 1, 4, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("SubServiceName : "), 0, 5, 1, 1, 100, 1);
		addCompCons(cboSerSId, 1, 5, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("Remarks : "), 0, 6, 1, 1, 100, 1);
		addCompCons(txtRemarks, 1, 6, 1, 1, 100, 1);
		
		
		table.addKeyListener(new actionListner());
		csuView();
		btnEnab(Actbtn.Deflt);
		clr(true);	
		cntEnabDisab(false);
		btnAdd.requestFocus();		
	}
	private class actionListner implements ActionListener,KeyListener{
		public void actionPerformed(ActionEvent e){			
			if (e.getActionCommand().equalsIgnoreCase("Add")){
				cntEnabDisab(true);
				String operClm[]={"TranDate","CustId","CustomerName","OrderMajorId","OrderSubId","ServId","ServiceName","SubServId","SubServiceName","Remarks"};		
				ArrayList<Object[]> data=new ArrayList<Object[]>();						
				Object[][] realData=data.toArray(new Object[data.size()][]);				
				table.setModel(new DefaultTableModel(realData, operClm){
					private static final long serialVersionUID = 1L;		
					public boolean isCellEditable(int row,int column){return false;}
				});
				modl=(DefaultTableModel) table.getModel();
				cboCustomer.requestFocus();
				btnEnab(Actbtn.Add);
			}else if (e.getActionCommand().equalsIgnoreCase("Save")){
				if(table.getRowCount() ==0){				
					JOptionPane.showMessageDialog(null, "Table Is Empty.",General.cmpTitle + "Service Transaction",JOptionPane.WARNING_MESSAGE);
					
				}else{
					ArrayList<GetSets> data=new ArrayList<GetSets>();
					//String operClm[]={"CustId","CustomerName","OrderDate","NoOfDelvDays","DeliveryDate","OrderSubject","OrderDetail"};
					//System.out.println(modl.getRowCount());
					//System.out.println(Integer.parseInt(modl.getValueAt(0, 0).toString()));
					Calendar cal=Calendar.getInstance();
					cal.setTime(new Date());
					SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");					
					//System.out.println(sdf.format(cal.getTime()));					
					System.out.println("Test");
					for(int r=0;r<modl.getRowCount();r++){
						GetSets gsar=new GetSets();						
						cal.setTime(new Date());
						gsar.setStn_Trandate(sdf.format(cal.getTime()));
						gsar.setGen_CustId(Integer.parseInt(modl.getValueAt(r, 1).toString()));
						gsar.setGen_OrderMajorId(Integer.parseInt(modl.getValueAt(r, 3).toString()));
						gsar.setGen_OrderSubId(Integer.parseInt(modl.getValueAt(r, 4).toString()));
						gsar.setGen_ServId(Integer.parseInt(modl.getValueAt(r, 5).toString()));
						gsar.setGen_SubServId(Integer.parseInt(modl.getValueAt(r, 7).toString()));
						gsar.setStn_Remarks(modl.getValueAt(r, 9).toString());
						data.add(gsar);
					}					
					System.out.println("Test1");
					if (DBMServiceTran.insertServiceTran(data)) {
						JOptionPane.showMessageDialog(null, "Saved.",General.cmpTitle + "Service Transaction",1);
						clr(true);
						csuView();
						btnEnab(Actbtn.Save);
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Saved.\n" + General.ErrMsg,General.cmpTitle + "Service Transaction",0);
					}									
				}				
			}else if (e.getActionCommand().equalsIgnoreCase("Edit")){
				
			}else if (e.getActionCommand().equalsIgnoreCase("Cancel")){
				clr(true);
				String operClm[]={"TranDate","CustId","CustomerName","OrderMajorId","OrderSubId","ServId","ServiceName","SubServId","SubServiceName","Remarks"};		
				ArrayList<Object[]> data=new ArrayList<Object[]>();						
				Object[][] realData=data.toArray(new Object[data.size()][]);				
				table.setModel(new DefaultTableModel(realData, operClm));
				btnEnab(Actbtn.Cancel);
			}else if (e.getActionCommand().equalsIgnoreCase("View")){
				csuView();				
			}else if (e.getActionCommand().equalsIgnoreCase("AddToGrid")){
				if(cboCustomer.getItemCount()==0
						|| cboSerId.getItemCount()==0						
						|| cboordMid.getItemCount()==0
						|| cboOrdSid.getItemCount()==0){				
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "Service Transaction",JOptionPane.WARNING_MESSAGE);
					
				}else{
				csrAddtoGrid();				
				cboOrdSid.requestFocus();
				txtRemarks.setText("");
				cboOrdSid.requestFocus();
				}
			}else if (e.getActionCommand().equalsIgnoreCase("Clear")){
				clr(false);
				g_rId=-1;
				btnAddtoGrid.setEnabled(true);
				btnEditGrid.setEnabled(false);
			}else if (e.getActionCommand().equalsIgnoreCase("EditGrid")){
				if(cboCustomer.getItemCount()==0
						|| cboSerId.getItemCount()==0						
						|| cboordMid.getItemCount()==0
						|| cboOrdSid.getItemCount()==0){				
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "Service Transaction",JOptionPane.WARNING_MESSAGE);
					
				}else{
					System.out.println("ine");
					System.out.println(g_rId);
					if (g_rId>=0){
						System.out.println("inef");
						String Custname=cboCustomer.getItemAt(cboCustomer.getSelectedIndex());
						String Service=cboSerId.getItemAt(cboSerId.getSelectedIndex());
						String subService=cboSerSId.getItemAt(cboSerSId.getSelectedIndex());						
						table.setValueAt(Custname.substring(Custname.indexOf("@")+1), g_rId, 1);				
						table.setValueAt(Custname.substring(0, Custname.indexOf("@")), g_rId, 2);				
						table.setValueAt(cboordMid.getItemAt(cboordMid.getSelectedIndex()).toString(), g_rId, 3);
						table.setValueAt(cboOrdSid.getItemAt(cboOrdSid.getSelectedIndex()).toString(), g_rId, 4);
						table.setValueAt(Service.substring(Service.indexOf("@")+1), g_rId, 5);				
						table.setValueAt(Service.substring(0, Service.indexOf("@")), g_rId, 6);
						table.setValueAt(subService.substring(subService.indexOf("@")+1), g_rId, 7);				
						table.setValueAt(subService.substring(0, subService.indexOf("@")), g_rId, 8);
						table.setValueAt(txtRemarks.getText().toString(), g_rId, 9);										
						clr(false);
						btnAddtoGrid.setEnabled(true);
						btnEditGrid.setEnabled(false);
						cboCustomer.requestFocus();
						g_rId=-1;
					}
				}
			}else if (e.getActionCommand().equalsIgnoreCase("cboOrdMajId")){
				DispOrSid(Integer.parseInt(cboordMid.getItemAt(cboordMid.getSelectedIndex()).toString()));
				if (cboOrdSid.getItemCount() > 0){cboOrdSid.setSelectedIndex(0);}
				cboOrdSid.requestFocus();
			}else if (e.getActionCommand().equalsIgnoreCase("cboSerId")){
				//System.out.println("ser");
				String Service=cboSerId.getItemAt(cboSerId.getSelectedIndex());
				DispSerSid(Integer.parseInt(Service.substring(Service.indexOf("@")+1).toString()));
				if (cboSerSId.getItemCount() > 0){cboSerSId.setSelectedIndex(0);}
				cboSerSId.requestFocus();
			}else if (e.getActionCommand().equalsIgnoreCase("Close")){
				dispose();
			}
		}
		public void keyTyped(KeyEvent e){
			
		}
		public void keyPressed(KeyEvent e){			
			if (e.getSource().equals(table)){				
				if (e.getKeyCode() == KeyEvent.VK_E && btnSave.isEnabled()){
					clr(true);
					cntEnabDisab(true);					
					int selrow=table.getSelectedRow();
					g_rId=selrow;
					int i;					
					String CustName=table.getValueAt(selrow, 1).toString() + " @" + table.getValueAt(selrow, 0).toString();					
					for (i=0 ;i < cboCustomer.getItemCount() ; i++){
						if(cboCustomer.getItemAt(i).equalsIgnoreCase(CustName)){
							cboCustomer.setSelectedIndex(i);
							break;
						}
					}
					String ordMid=table.getValueAt(selrow, 3).toString();					
					for (i=0 ;i < cboordMid.getItemCount() ; i++){
						if(cboordMid.getItemAt(i).equalsIgnoreCase(ordMid)){
							cboordMid.setSelectedIndex(i);
							break;
						}
					}
					String ordSid=table.getValueAt(selrow, 4).toString();					
					for (i=0 ;i < cboOrdSid.getItemCount() ; i++){
						if(cboOrdSid.getItemAt(i).equalsIgnoreCase(ordSid)){
							cboOrdSid.setSelectedIndex(i);
							break;
						}
					}
					
					String Service=table.getValueAt(selrow, 6).toString() + " @" + table.getValueAt(selrow, 5).toString();					
					for (i=0 ;i < cboSerId.getItemCount() ; i++){
						if(cboSerId.getItemAt(i).equalsIgnoreCase(Service)){
							cboSerId.setSelectedIndex(i);
							break;
						}
					}
					String SubService=table.getValueAt(selrow, 8).toString() + " @" + table.getValueAt(selrow, 7).toString();					
					for (i=0 ;i < cboSerSId.getItemCount() ; i++){
						if(cboSerSId.getItemAt(i).equalsIgnoreCase(SubService)){
							cboSerSId.setSelectedIndex(i);
							break;
						}
					}
					txtRemarks.setText(table.getValueAt(selrow, 9).toString());
					cboCustomer.requestFocus();
					btnAddtoGrid.setEnabled(false);
					btnEditGrid.setEnabled(true);
					//btnEnab(Actbtn.Edit);					
				}else if (e.getKeyCode() == KeyEvent.VK_R && btnSave.isEnabled()){
					if(table.getRowCount() ==0){
						JOptionPane.showMessageDialog(null, "Table Is Empty.",General.cmpTitle + "Customer Service Registration",JOptionPane.WARNING_MESSAGE);						
					}else if(g_rId==table.getSelectedRow()){
						JOptionPane.showMessageDialog(null, "You Selected Row is in Edit Mode., Please Click ClearButton and Continue.",General.cmpTitle + "Customer Service Registration",JOptionPane.WARNING_MESSAGE);						
					}else{					
						int retout=JOptionPane.showConfirmDialog(null,"Confirm To Remove?",General.cmpTitle + "Customer Service Registration",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
						if (retout==JOptionPane.YES_OPTION){
							int selrow=table.getSelectedRow();
							modl.removeRow(selrow);
						}
					}
				}
			}else if (e.getSource().equals(cboordMid)){				
				if (e.getKeyCode() == KeyEvent.VK_ENTER){
					System.out.println("ord");
					DispOrSid(Integer.parseInt(cboordMid.getItemAt(cboordMid.getSelectedIndex()).toString()));
					if (cboOrdSid.getItemCount() > 0){cboOrdSid.setSelectedIndex(0);}
					cboOrdSid.requestFocus();
				}
				
			}else if (e.getSource().equals(cboSerId)){				
				if (e.getKeyCode() == KeyEvent.VK_ENTER){
					System.out.println("ser");
					String Service=cboSerId.getItemAt(cboSerId.getSelectedIndex());
					DispSerSid(Integer.parseInt(Service.substring(Service.indexOf("@")+1).toString()));
					if (cboSerSId.getItemCount() > 0){cboSerSId.setSelectedIndex(0);}
					cboSerSId.requestFocus();
				}
			}
		}
		public void keyReleased(KeyEvent e){
			
		}
	}
	public void clr(Boolean enab){
		if (cboCustomer.getItemCount() > 0){cboCustomer.setSelectedIndex(0);}
		if (cboordMid.getItemCount() > 0){cboordMid.setSelectedIndex(0);}
		if (cboOrdSid.getItemCount() > 0){cboOrdSid.setSelectedIndex(0);}
		if (cboSerId.getItemCount() > 0){cboSerId.setSelectedIndex(0);}
		if (cboSerSId.getItemCount() > 0){cboSerSId.setSelectedIndex(0);}
		txtRemarks.setText("");				
		if (enab) {cntEnabDisab(false);}
		g_rId=-1;
		btnEditGrid.setEnabled(false);
	}
	public void addCompCons(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		panel.add(cmp,gbc);
		
	}
	public void addFrmComp(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		add(cmp,gbc);
		
	}
	private void addBtnCons(JButton btn,Character mne,String actcmd){
		btn.addActionListener(new actionListner());
		btn.setActionCommand(actcmd);
		btn.setMnemonic(mne);
	}
	private void btnEnab(Actbtn btn){
		switch (btn){
		case Add:
			btnEnabDisab(false, true, false, true, false);
			break;
		case Save:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Edit:
			btnEnabDisab(false, false, true, true, false);
			break;
		case Cancel:
			btnEnabDisab(true, false, false, true, true);
			table.removeAll();
			break;
		case View:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Deflt:
			btnEnabDisab(true, false, false, true, true);
			break;
		}
	}
	private void btnEnabDisab(Boolean btAdd,Boolean btSave,Boolean btEdit,Boolean btCancel,Boolean btView){
		btnAdd.setEnabled(btAdd);
		btnSave.setEnabled(btSave);		
		btnCancel.setEnabled(btCancel);
		btnView.setEnabled(btView);
	}
	private void cntEnabDisab(Boolean val){
		cboCustomer.setEnabled(val);
		cboordMid.setEnabled(val);
		cboOrdSid.setEnabled(val);
		cboSerId.setEnabled(val);		
		cboSerSId.setEnabled(val);
		txtRemarks.setEnabled(val);
		btnAddtoGrid.setEnabled(val);
		btnAddCancel.setEnabled(val);
		//btnEditGrid.setEnabled(val);
	}
	private void csrAddtoGrid(){								
		
		table.setBorder(new LineBorder(new Color(0,0,0)));			
		String Custname=cboCustomer.getItemAt(cboCustomer.getSelectedIndex());
		String Service=cboSerId.getItemAt(cboSerId.getSelectedIndex());
		String subService=cboSerSId.getItemAt(cboSerSId.getSelectedIndex());		
		Object[] realdate=new Object[]{lbldate.getText().toString(),
				Custname.substring(Custname.indexOf("@")+1),
				Custname.substring(0, Custname.indexOf("@")),
				cboordMid.getItemAt(cboordMid.getSelectedIndex()).toString(),
				cboOrdSid.getItemAt(cboOrdSid.getSelectedIndex()).toString(),
				Service.substring(Service.indexOf("@")+1),
				Service.substring(0, Service.indexOf("@")),
				subService.substring(subService.indexOf("@")+1),
				subService.substring(0, subService.indexOf("@")),
				txtRemarks.getText().toString()};	
		modl.addRow(realdate);
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);		
	}
	private void csuView(){		
		String operClm[]={"SerTranId","TranDate","CustId","CustomerName","OrderMajorId","OrderSubId","ServId","ServiceName","SubServId","SubServiceName","Remarks"};
		ArrayList<Object[]> data=new ArrayList<Object[]>();				
		data=DBMServiceTran.viewServiceTran();				
		Object[][] realData=data.toArray(new Object[data.size()][]);				
		table.setBorder(new LineBorder(new Color(0,0,0)));
		table.setModel(new DefaultTableModel(realData,operClm){
			private static final long serialVersionUID = 1L;		
			public boolean isCellEditable(int row,int column){return false;}
		});
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);				
	}
	private void DispCust(){
		ArrayList<String> data=new ArrayList<String>();
		data=DBMServiceTran.dispCust();		
		for(String el : data){
			cboCustomer.addItem(el.toString());
		}		
	}
	private void DispOrMid(){
		ArrayList<String> data=new ArrayList<String>();
		data=DBMServiceTran.dispOrder();		
		for(String el : data){
			cboordMid.addItem(el.toString());
		}		
	}
	private void DispOrSid(int ordmId){
		ArrayList<String> data=new ArrayList<String>();
		data=DBMServiceTran.dispSubOrd(ordmId);
		cboOrdSid.removeAllItems();
		for(String el : data){
			cboOrdSid.addItem(el.toString());
		}		
	}
	private void DispSerId(){
		ArrayList<String> data=new ArrayList<String>();
		data=DBMServiceTran.dispService();		
		for(String el : data){
			cboSerId.addItem(el.toString());
		}		
	}
	private void DispSerSid(int srvid){
		ArrayList<String> data=new ArrayList<String>();
		data=DBMServiceTran.dispSubService(srvid);
		cboSerSId.removeAllItems();
		for(String el : data){
			cboSerSId.addItem(el.toString());
		}		
	}
	}

package com.draw;


import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

public class FrmOperCreation extends JInternalFrame {
	/**
	 *Operator Creation 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel lblhedr,lblFootr;
	private JTable table;
	private JPanel cntrlpanel,panel,btnPanel;
	private GridBagLayout gbcl;
	private GridBagConstraints gbcc;
	private JButton btnAdd,btnSave,btnEdit,btnCancel,btnClose,btnview;
	private JTextField txtFirstName,txtLastName,txtUser;
	private JPasswordField txtPass;
	private JCheckBox chkActive;
	private int g_operid;
	private enum Actbtn{
		Deflt,Add,Save,Edit,Cancel,View,Close}
	

	public FrmOperCreation(){
		this.setTitle("Operator Creation");
		this.setResizable(true);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setIconifiable(true);
		this.pack();
		prepareGUI();
		clr();
	}	
	public void prepareGUI(){		
		setLayout(new GridBagLayout());
		gbcc=new GridBagConstraints();
		lblhedr=new JLabel("Operator Creation",JLabel.CENTER);		
		lblhedr.setFont(new Font("Verdana", Font.BOLD, 18));
		cntrlpanel=new JPanel();
		
		gbcc.fill=GridBagConstraints.BOTH;
		addmaincomp(lblhedr, 0, 0, 1, 1, 100, 1);
		gbcc.fill=GridBagConstraints.BOTH;
		addmaincomp(cntrlpanel, 0, 1, 1, 1, 100, 1);		
		//View Pannel Start		
		btnPanel=new JPanel();
		btnPanel.setLayout(new FlowLayout());
		
		btnAdd=new JButton("Add");			
		btnCancel=new JButton("Cancel");				
		btnClose=new JButton("Close");
		btnEdit=new JButton("Edit");
		btnSave=new JButton("Save");
		btnview=new JButton("view");
		
		addBtnCons(btnAdd,'A',"Add");	
		addBtnCons(btnCancel,'C',"Cancel");
		addBtnCons(btnClose,'l',"Close");
		addBtnCons(btnEdit,'E',"Edit");
		addBtnCons(btnSave,'S',"Save");
		addBtnCons(btnview,'V',"View");
		
		btnPanel.add(btnAdd);
		btnPanel.add(btnSave);
		btnPanel.add(btnEdit);
		btnPanel.add(btnCancel);
		btnPanel.add(btnview);
		btnPanel.add(btnClose);		
		table=new JTable();
		table.addKeyListener(new BtnClickListioner());
		JScrollPane srl=new JScrollPane(table);
		lblFootr=new JLabel("Select Row and Press [E] For Edit",JLabel.CENTER);
		lblFootr.setFont(new Font("Arial", Font.BOLD, 14));
		gbcc.fill=GridBagConstraints.BOTH;
		addmaincomp(btnPanel, 0, 2, 1, 1, 100, 1);
		gbcc.fill=GridBagConstraints.BOTH;
		addmaincomp(srl, 0, 3, 1, 1, 100, 3);
		gbcc.fill=GridBagConstraints.BOTH;
		addmaincomp(lblFootr, 0, 4, 1, 1, 100, 1);
		//View Pannel End		
		showOperCreation();		
		acrfrmView();
		btnEnab(Actbtn.Deflt);
		btnAdd.requestFocus();		
	}
	public void showOperCreation(){
		gbcl=new GridBagLayout();		
		panel=new JPanel();
		panel.setLayout(gbcl);
		gbcc.fill=GridBagConstraints.BOTH;
		gbcc.ipadx=20;
		txtFirstName=new JTextField(20);
		txtLastName=new JTextField(20);
		txtUser=new JTextField(20);		
		txtPass =new JPasswordField(20);
		chkActive=new JCheckBox();
		
		addcomponent(new JLabel("FirstName :"), 0, 0, 1, 1, 100, 1);
		addcomponent(txtFirstName, 1, 0, 1, 1, 100, 1);
		
		gbcc.fill=GridBagConstraints.BOTH;
		addcomponent(new JLabel("LastName :"), 0, 1, 1, 1, 100, 1);
		addcomponent(txtLastName, 1, 1, 1, 1, 100, 1);
		
		gbcc.fill=GridBagConstraints.BOTH;
		addcomponent(new JLabel("UserName :"), 0, 2, 1, 1, 100, 1);
		addcomponent(txtUser, 1, 2, 1, 1, 100, 1);
		
		gbcc.fill=GridBagConstraints.BOTH;
		addcomponent(new JLabel("Password :"), 0, 3, 1, 1, 100, 1);
		addcomponent(txtPass, 1, 3, 1, 1, 100, 1);
		
		gbcc.fill=GridBagConstraints.BOTH;
		addcomponent(new JLabel("Active :"), 0, 4, 1, 1, 100, 1);
		addcomponent(chkActive, 1, 4, 1, 1, 100, 1);
		cntrlpanel.add(panel);
	}
	public void addcomponent(Component cmp,int r,int c,int w,int h,int wx,int wy){
		gbcc.gridx=r;
		gbcc.gridy=c;
		gbcc.gridwidth=w;
		gbcc.gridheight=h;
		gbcc.weightx=wx;
		gbcc.weighty=wy;
		panel.add(cmp, gbcc);
	}
	public void addmaincomp(Component cmp,int r,int c,int w,int h,int wx,int wy){
		gbcc.gridx=r;
		gbcc.gridy=c;
		gbcc.gridwidth=w;
		gbcc.gridheight=h;
		gbcc.weightx=wx;
		gbcc.weighty=wy;
		add(cmp, gbcc);		
	}
	public void addBtnCons(JButton btn,Character mne,String actcmd){
		btn.addActionListener(new BtnClickListioner());
		btn.setActionCommand(actcmd);
		btn.setMnemonic(mne);
	}
	public class BtnClickListioner implements ActionListener,KeyListener{			
		@SuppressWarnings("deprecation")		
		public void actionPerformed(ActionEvent e){
			GetSets gs=new GetSets();
			if (e.getActionCommand().equalsIgnoreCase("Add")){
				cntEnabDisab(true);
				btnEnab(Actbtn.Add);
				txtFirstName.requestFocus();
			}else if (e.getActionCommand().equalsIgnoreCase("Save")){
				if(txtFirstName.getText().equalsIgnoreCase("") || txtLastName.getText().equalsIgnoreCase("") 
						|| txtUser.getText().equalsIgnoreCase("") || txtPass.getText().equalsIgnoreCase("")){
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "OperCreation",JOptionPane.WARNING_MESSAGE);
					
				}else{
					gs.setOper_FirstName(txtFirstName.getText().toString());
					gs.setOper_LastName(txtLastName.getText().toString());
					gs.setOper_userName(txtUser.getText().toString());
					gs.setOper_Password(txtPass.getText().toString());
					gs.setGen_Active(chkActive.isSelected() ? "Y" : "N");
					if (DBMOperCreation.insertOperator(gs)) {
						JOptionPane.showMessageDialog(null, "Saved.",General.cmpTitle + "OperCreation",1);
						clr();
						acrfrmView();
						btnEnab(Actbtn.Save);
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Saved.\n" + General.ErrMsg,General.cmpTitle + "OperCreation",0);
					}									
				}
			}else if (e.getActionCommand().equalsIgnoreCase("Edit")){				
				if(txtFirstName.getText().equalsIgnoreCase("") || txtLastName.getText().equalsIgnoreCase("") 
						|| txtUser.getText().equalsIgnoreCase("") || txtPass.getText().equalsIgnoreCase("")){
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "OperCreation",JOptionPane.WARNING_MESSAGE);
					
				}else{
					GetSets set=new GetSets();
					set.setOper_FirstName(txtFirstName.getText().toString());
					set.setOper_LastName(txtLastName.getText().toString());
					set.setOper_userName(txtUser.getText().toString());
					set.setOper_Password(txtPass.getText().toString());
					set.setGen_Active(chkActive.isSelected() ? "Y" : "N");
					set.setGen_OperId(g_operid);
					System.out.println(set.getGen_OperId());
					if (DBMOperCreation.updateOperator(set)) {
						JOptionPane.showMessageDialog(null, "Edited.",General.cmpTitle + "OperCreation",1);
						clr();
						btnEnab(Actbtn.Save);
						acrfrmView();						
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Edited.\n" + General.ErrMsg,General.cmpTitle + "OperCreation",0);
					}					
				}
			}else if (e.getActionCommand().equalsIgnoreCase("Cancel")){
				clr();
				btnEnab(Actbtn.Cancel);
			}else if (e.getActionCommand().equalsIgnoreCase("View")){				
				acrfrmView();
				btnEnab(Actbtn.View);
			}else if (e.getActionCommand().equalsIgnoreCase("Close")){				
				dispose();
			}
		}
		public void keyTyped(KeyEvent e){
			
		}
		public void keyPressed(KeyEvent e){
			if(e.getKeyCode()==KeyEvent.VK_E){
				if (e.getSource().equals(table)){				
					cntEnabDisab(true);
					int selectedrow=table.getSelectedRow();
					txtFirstName.setText((String) table.getValueAt(selectedrow, 1));
					txtLastName.setText((String) table.getValueAt(selectedrow, 2));
					txtUser.setText((String) table.getValueAt(selectedrow, 3));
					txtPass.setText((String) table.getValueAt(selectedrow, 5));
					if(table.getValueAt(selectedrow, 4).toString().equalsIgnoreCase("Y")){
						chkActive.setSelected(true);
					}else{
						chkActive.setSelected(false);
					}
					g_operid=Integer.parseInt(table.getValueAt(selectedrow, 0).toString());
					btnEnab(Actbtn.Edit);
					txtFirstName.requestFocus();
				}
			}
			
		}
		public void keyReleased(KeyEvent e){
			
		}
		
	}
	private void acrfrmView(){		
		String operClm[]={"OperId","FirstName","LastName","UserName","Active","Pass"};
		ArrayList<Object[]> data=new ArrayList<Object[]>();				
		data=DBMOperCreation.viewOperator();				
		Object[][] realData=data.toArray(new Object[data.size()][]);				
		table.setBorder(new LineBorder(new Color(0,0,0)));
		table.setModel(new DefaultTableModel(realData,operClm){
			private static final long serialVersionUID = 1L;		
			public boolean isCellEditable(int row,int column){return false;}
		});
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		table.getColumnModel().getColumn(5).setResizable(false);
		table.getColumnModel().getColumn(5).setPreferredWidth(0);
		table.getColumnModel().getColumn(5).setMinWidth(0);
		table.getColumnModel().getColumn(5).setMaxWidth(0);		
	}
	private void btnEnab(Actbtn btn){
		switch (btn){
		case Add:
			btnEnabDisab(false, true, false, true, false);
			break;
		case Save:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Edit:
			btnEnabDisab(false, false, true, true, false);
			break;
		case Cancel:
			btnEnabDisab(true, false, false, true, true);
			break;
		case View:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Deflt:
			btnEnabDisab(true, false, false, true, true);
			break;
		}
	}
	private void btnEnabDisab(Boolean btAdd,Boolean btSave,Boolean btEdit,Boolean btCancel,Boolean btView){
		btnAdd.setEnabled(btAdd);
		btnSave.setEnabled(btSave);
		btnEdit.setEnabled(btEdit);
		btnCancel.setEnabled(btCancel);
		btnview.setEnabled(btView);
	}
	private void clr(){
		txtFirstName.setText("");
		txtLastName.setText("");
		txtUser.setText("");
		txtPass.setText("");
		txtFirstName.setActionCommand("");
		chkActive.setSelected(true);
		cntEnabDisab(false);		
	}
	private void cntEnabDisab(Boolean val){
		txtFirstName.setEnabled(val);
		txtLastName.setEnabled(val);
		txtUser.setEnabled(val);
		txtPass.setEnabled(val);
		chkActive.setEnabled(val);
	}
}

package com.draw;

public class GetSets {
	
	//Common
	private static int Comm_OperId;
	private static String Comm_NodeId;

	//General	
	//private static Date serv_Date;
	private String Gen_Active;
	private int Gen_OperId;
	private int Gen_RateId;
	private int Gen_ServId;
	private int Gen_SubServId;
	private int Gen_CustId;
	private int Gen_OrderMajorId;
	private int Gen_OrderSubId;
	private int Gen_SerTranid;
	private int Gen_SerStatusId;
	
	//Operator	
	private String oper_FirstName;
	private String oper_LastName;
	private String oper_userName;
	private String oper_Password;
	
	
	//Rate Master	
	private Double ratem_Rate;		
	
	//Service Mast	
	private String servm_ServiceName;	
	private String servm_SubService;
	
	//Sub Service Mast	
	private String subservm_SubServiceName;	
	
	//Cust SignUp
	private String cum_custname;
	private String cum_motbikeno;
	private String cum_motbikename;
	private String cum_mobieno;
	private String cum_emailaddr;
	private String cum_cregpwd;
	private String cum_cregcpwd;
	
	//Cust Registration Summery	
	private String crm_ordersubject;
	private String crm_OrderDate;	
	private String crm_ordercancel;
	private String crm_orddetsmry;
	private String crm_orddeliverydate;
	private String crm_orddetail;
	
	//Service Tran
	private String stn_Trandate;	
	private String stn_Cancel;
	private String stn_Remarks;
	
	//Custreg Status Updation
	private String crs_OveralChFlag;
	private int crs_battery;
	private int crs_engine;
	private int crs_suspension;
	private int crs_breaks;
	private int crs_exterior;
	private int crs_tyres;
	private int crs_electrical;
	private int crs_seats;
	private int crs_overal;
	private String crs_remarks;
	
	
	public String getGen_Active() {
		return Gen_Active;
	}
	public void setGen_Active(String gen_Active) {
		Gen_Active = gen_Active;
	}
	public int getGen_OperId() {
		return Gen_OperId;
	}
	public void setGen_OperId(int gen_OperId) {
		Gen_OperId = gen_OperId;
	}
	public int getGen_RateId() {
		return Gen_RateId;
	}
	public void setGen_RateId(int gen_RateId) {
		Gen_RateId = gen_RateId;
	}
	public int getGen_ServId() {
		return Gen_ServId;
	}
	public void setGen_ServId(int gen_ServId) {
		Gen_ServId = gen_ServId;
	}
	public String getOper_FirstName() {
		return oper_FirstName;
	}
	public void setOper_FirstName(String oper_FirstName) {
		this.oper_FirstName = oper_FirstName;
	}
	public String getOper_LastName() {
		return oper_LastName;
	}
	public void setOper_LastName(String oper_LastName) {
		this.oper_LastName = oper_LastName;
	}
	public String getOper_userName() {
		return oper_userName;
	}
	public void setOper_userName(String oper_userName) {
		this.oper_userName = oper_userName;
	}
	public String getOper_Password() {
		return oper_Password;
	}
	public void setOper_Password(String oper_Password) {
		this.oper_Password = oper_Password;
	}
	
	public String getServm_ServiceName() {
		return servm_ServiceName;
	}
	public void setServm_ServiceName(String servm_ServiceName) {
		this.servm_ServiceName = servm_ServiceName;
	}
	public String getServm_SubService() {
		return servm_SubService;
	}
	public void setServm_SubService(String servm_SubService) {
		this.servm_SubService = servm_SubService;
	}
	public String getSubservm_SubServiceName() {
		return subservm_SubServiceName;
	}
	public void setSubservm_SubServiceName(String subservm_SubServiceName) {
		this.subservm_SubServiceName = subservm_SubServiceName;
	}
	public int getGen_SubServId() {
		return Gen_SubServId;
	}
	public void setGen_SubServId(int gen_SubServId) {
		Gen_SubServId = gen_SubServId;
	}
	public static int getComm_OperId() {
		return Comm_OperId;
	}
	public static void setComm_OperId(int comm_OperId) {
		Comm_OperId = comm_OperId;
	}
	public static String getComm_NodeId() {
		return Comm_NodeId;
	}
	public static void setComm_NodeId(String comm_NodeId) {
		Comm_NodeId = comm_NodeId;
	}
	public int getGen_CustId() {
		return Gen_CustId;
	}
	public void setGen_CustId(int gen_CustId) {
		Gen_CustId = gen_CustId;
	}
	public String getCum_custname() {
		return cum_custname;
	}
	public void setCum_custname(String cum_custname) {
		this.cum_custname = cum_custname;
	}
	public String getCum_motbikeno() {
		return cum_motbikeno;
	}
	public void setCum_motbikeno(String cum_motbikeno) {
		this.cum_motbikeno = cum_motbikeno;
	}
	public String getCum_motbikename() {
		return cum_motbikename;
	}
	public void setCum_motbikename(String cum_motbikename) {
		this.cum_motbikename = cum_motbikename;
	}
	public String getCum_mobieno() {
		return cum_mobieno;
	}
	public void setCum_mobieno(String cum_mobieno) {
		this.cum_mobieno = cum_mobieno;
	}
	public String getCum_emailaddr() {
		return cum_emailaddr;
	}
	public void setCum_emailaddr(String cum_emailaddr) {
		this.cum_emailaddr = cum_emailaddr;
	}
	public String getCum_cregpwd() {
		return cum_cregpwd;
	}
	public void setCum_cregpwd(String cum_cregpwd) {
		this.cum_cregpwd = cum_cregpwd;
	}
	public String getCum_cregcpwd() {
		return cum_cregcpwd;
	}
	public void setCum_cregcpwd(String cum_cregcpwd) {
		this.cum_cregcpwd = cum_cregcpwd;
	}
	public int getGen_OrderMajorId() {
		return Gen_OrderMajorId;
	}
	public void setGen_OrderMajorId(int gen_OrderMajorId) {
		Gen_OrderMajorId = gen_OrderMajorId;
	}
	public String getCrm_ordersubject() {
		return crm_ordersubject;
	}
	public void setCrm_ordersubject(String crm_ordersubject) {
		this.crm_ordersubject = crm_ordersubject;
	}	
	public String getCrm_ordercancel() {
		return crm_ordercancel;
	}
	public void setCrm_ordercancel(String crm_ordercancel) {
		this.crm_ordercancel = crm_ordercancel;
	}
	public String getCrm_orddetsmry() {
		return crm_orddetsmry;
	}
	public void setCrm_orddetsmry(String crm_orddetsmry) {
		this.crm_orddetsmry = crm_orddetsmry;
	}		
	public int getGen_OrderSubId() {
		return Gen_OrderSubId;
	}
	public void setGen_OrderSubId(int gen_OrderSubId) {
		Gen_OrderSubId = gen_OrderSubId;
	}
	public String getStn_Cancel() {
		return stn_Cancel;
	}
	public void setStn_Cancel(String stn_Cancel) {
		this.stn_Cancel = stn_Cancel;
	}	
	public String getCrs_OveralChFlag() {
		return crs_OveralChFlag;
	}
	public void setCrs_OveralChFlag(String crs_OveralChFlag) {
		this.crs_OveralChFlag = crs_OveralChFlag;
	}
	
	public int getGen_SerTranid() {
		return Gen_SerTranid;
	}
	public void setGen_SerTranid(int gen_SerTranid) {
		Gen_SerTranid = gen_SerTranid;
	}
	public int getGen_SerStatusId() {
		return Gen_SerStatusId;
	}
	public void setGen_SerStatusId(int gen_SerStatusId) {
		Gen_SerStatusId = gen_SerStatusId;
	}
	public Double getRatem_Rate() {
		return ratem_Rate;
	}
	public void setRatem_Rate(Double ratem_Rate) {
		this.ratem_Rate = ratem_Rate;
	}
	public String getCrm_orddeliverydate() {
		return crm_orddeliverydate;
	}
	public void setCrm_orddeliverydate(String string) {
		this.crm_orddeliverydate = string;
	}
	public String getCrm_orddetail() {
		return crm_orddetail;
	}
	public void setCrm_orddetail(String crm_orddetail) {
		this.crm_orddetail = crm_orddetail;
	}
	public String getCrm_OrderDate() {
		return crm_OrderDate;
	}
	public void setCrm_OrderDate(String crm_OrderDate) {
		this.crm_OrderDate = crm_OrderDate;
	}
	public String getStn_Trandate() {
		return stn_Trandate;
	}
	public void setStn_Trandate(String stn_Trandate) {
		this.stn_Trandate = stn_Trandate;
	}
	public String getStn_Remarks() {
		return stn_Remarks;
	}
	public void setStn_Remarks(String stn_Remarks) {
		this.stn_Remarks = stn_Remarks;
	}
	public String getCrs_remarks() {
		return crs_remarks;
	}
	public void setCrs_remarks(String crs_remarks) {
		this.crs_remarks = crs_remarks;
	}
	public int getCrs_battery() {
		return crs_battery;
	}
	public void setCrs_battery(int crs_battery) {
		this.crs_battery = crs_battery;
	}
	public int getCrs_engine() {
		return crs_engine;
	}
	public void setCrs_engine(int crs_engine) {
		this.crs_engine = crs_engine;
	}
	public int getCrs_suspension() {
		return crs_suspension;
	}
	public void setCrs_suspension(int crs_suspension) {
		this.crs_suspension = crs_suspension;
	}
	public int getCrs_breaks() {
		return crs_breaks;
	}
	public void setCrs_breaks(int crs_breaks) {
		this.crs_breaks = crs_breaks;
	}
	public int getCrs_exterior() {
		return crs_exterior;
	}
	public void setCrs_exterior(int crs_exterior) {
		this.crs_exterior = crs_exterior;
	}
	public int getCrs_tyres() {
		return crs_tyres;
	}
	public void setCrs_tyres(int crs_tyres) {
		this.crs_tyres = crs_tyres;
	}
	public int getCrs_electrical() {
		return crs_electrical;
	}
	public void setCrs_electrical(int crs_electrical) {
		this.crs_electrical = crs_electrical;
	}
	public int getCrs_seats() {
		return crs_seats;
	}
	public void setCrs_seats(int crs_seats) {
		this.crs_seats = crs_seats;
	}
	public int getCrs_overal() {
		return crs_overal;
	}
	public void setCrs_overal(int crs_overal) {
		this.crs_overal = crs_overal;
	}
	
	
	
	// General Getter Setter Ends Here.	
	/*public static Date getServ_Date() {
		return serv_Date;
	}
	public static void setServ_Date(Date serv_Date) {
		GetSets.serv_Date = serv_Date;
	}*/
	// General Getter Setter Ends Here.
	
	
	// Operator Getter Setter Starts Here.
		
}

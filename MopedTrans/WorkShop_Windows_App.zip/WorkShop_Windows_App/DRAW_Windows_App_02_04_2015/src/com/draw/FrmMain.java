package com.draw;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class FrmMain extends JFrame {	
	/**
	 * Main Module
	 */
	private static final long serialVersionUID = 1L;
	private JDesktopPane theDeskTopPane;
	private JMenuBar bar;
	private JMenu menumast;
	public FrmMain(){
		bar=new JMenuBar();
		menumast=new JMenu("Mster");
		menumast.setMnemonic('M');
		
		JMenuItem mnuoper=new JMenuItem("OperatorMast");
		mnuoper.setMnemonic('O');
		mnuoper.setActionCommand("Operator");
		mnuoper.addActionListener(new MenuClickListener());
		
		JMenuItem mnurate=new JMenuItem("RateMast");
		mnurate.setMnemonic('R');
		mnurate.setActionCommand("Rate");
		mnurate.addActionListener(new MenuClickListener());
		
		JMenuItem mnuservicemast=new JMenuItem("ServiceMast");
		mnuservicemast.setMnemonic('S');
		mnuservicemast.setActionCommand("ServiceMast");
		mnuservicemast.addActionListener(new MenuClickListener());
		
		JMenuItem mnusubservicemast=new JMenuItem("SubServiceMast");
		mnusubservicemast.setMnemonic('U');
		mnusubservicemast.setActionCommand("SubServiceMast");
		mnusubservicemast.addActionListener(new MenuClickListener());
		
		JMenuItem mnucustsup=new JMenuItem("CustSignUp");
		mnucustsup.setMnemonic('C');
		mnucustsup.setActionCommand("CustSignUp");
		mnucustsup.addActionListener(new MenuClickListener());

		menumast.add(mnuoper);		
		menumast.addSeparator();
		menumast.add(mnurate);
		menumast.addSeparator();
		menumast.add(mnuservicemast);
		menumast.addSeparator();
		menumast.add(mnusubservicemast);
		menumast.addSeparator();
		menumast.add(mnucustsup);
		
		JMenu mnuTrans =new JMenu("Transaction");
		mnuTrans.setMnemonic('T');
		
		JMenuItem mnuServReg=new JMenuItem("ServiceRegistration");
		mnuServReg.setActionCommand("ServReg");
		mnuServReg.setMnemonic('S');		
		mnuServReg.addActionListener(new MenuClickListener());
		
		JMenuItem mnuServTran=new JMenuItem("ServiceTransaction");
		mnuServTran.setActionCommand("ServTran");
		mnuServTran.setMnemonic('T');		
		mnuServTran.addActionListener(new MenuClickListener());
		
		JMenuItem mnuRegStUpd=new JMenuItem("Reg-StatusUpdation");
		mnuRegStUpd.setActionCommand("RegStUpd");
		mnuRegStUpd.setMnemonic('U');		
		mnuRegStUpd.addActionListener(new MenuClickListener());
		
		mnuTrans.add(mnuServReg);
		mnuTrans.addSeparator();
		mnuTrans.add(mnuServTran);
		mnuTrans.addSeparator();
		mnuTrans.add(mnuRegStUpd);
		
		JMenu mnuSys =new JMenu("System");
		mnuSys.setMnemonic('y');
		
		JMenuItem mnuexit=new JMenuItem("Exit");
		mnuexit.setActionCommand("exit");
		mnuexit.setMnemonic('x');		
		mnuexit.addActionListener(new MenuClickListener());
		
		mnuSys.add(mnuexit);
		
		bar.add(menumast);
		bar.add(mnuTrans);
		bar.add(mnuSys);
		
		setJMenuBar(bar);
		theDeskTopPane=new JDesktopPane();
		add(theDeskTopPane);
	}
	
public class MenuClickListener implements ActionListener {
	public void actionPerformed(ActionEvent e){
		String cmd=e.getActionCommand();		
		if (cmd.equalsIgnoreCase("OPerator")){			
			FrmOperCreation oprcr=new FrmOperCreation();			
			theDeskTopPane.add(oprcr);
			oprcr.setVisible(true);
			oprcr.setSize(theDeskTopPane.getWidth(), theDeskTopPane.getHeight());			
		}else if (cmd.equalsIgnoreCase("Rate")){
			FrmRateMaster ratm=new FrmRateMaster();			
			theDeskTopPane.add(ratm);
			ratm.setVisible(true);
			ratm.setSize(theDeskTopPane.getWidth(), theDeskTopPane.getHeight());
		}else if (cmd.equalsIgnoreCase("ServiceMast")){
			FrmServiceMast serm=new FrmServiceMast();			
			theDeskTopPane.add(serm);
			serm.setVisible(true);
			serm.setSize(theDeskTopPane.getWidth(), theDeskTopPane.getHeight());
		}else if (cmd.equalsIgnoreCase("SubServiceMast")){
			FrmSubServiceMast subserm=new FrmSubServiceMast();			
			theDeskTopPane.add(subserm);
			subserm.setVisible(true);
			subserm.setSize(theDeskTopPane.getWidth(), theDeskTopPane.getHeight());
		}else if (cmd.equalsIgnoreCase("CustSignUp")){
			FrmCustSignUp custsiup=new FrmCustSignUp();			
			theDeskTopPane.add(custsiup);
			custsiup.setVisible(true);
			custsiup.setSize(theDeskTopPane.getWidth(), theDeskTopPane.getHeight());
		}else if (cmd.equalsIgnoreCase("ServReg")){
			FrmCustRegSum custsreg=new FrmCustRegSum();			
			theDeskTopPane.add(custsreg);
			custsreg.setVisible(true);
			custsreg.setSize(theDeskTopPane.getWidth(), theDeskTopPane.getHeight());			
		}else if (cmd.equalsIgnoreCase("ServTran")){
			FrmServiceTran servtran=new FrmServiceTran();			
			theDeskTopPane.add(servtran);
			servtran.setVisible(true);
			servtran.setSize(theDeskTopPane.getWidth(), theDeskTopPane.getHeight());
		}else if (cmd.equalsIgnoreCase("RegStUpd")){
			FrmCustRegStatus curegst=new FrmCustRegStatus();			
			theDeskTopPane.add(curegst);
			curegst.setVisible(true);
			curegst.setSize(theDeskTopPane.getWidth(), theDeskTopPane.getHeight());
		}else if (cmd.equalsIgnoreCase("exit")){			
			System.exit(0);
		}
	}
	
	
}


}

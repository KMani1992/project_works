package com.draw;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;


public class FrmSubServiceMast  extends JInternalFrame {
	/**
	 * Sub Service Master
	 */
	private static final long serialVersionUID = 1L;
	private GridBagConstraints gbc;
	private JPanel btnPanel,panel,cntrlPanel;
	private JLabel lblheader,lblBottom;
	private JTextField txtSubServicename;
	private JCheckBox chkActive;
	private JComboBox<String> cboRate,cboService;
	private int g_SubSerId;
	private JTable table;
	private JButton btnAdd,btnSave,btnEdit,btnCancel,btnClose,btnview;
	private enum Actbtn{
		Deflt,Add,Save,Edit,Cancel,View,Close}

	public FrmSubServiceMast(){
		this.setTitle("SubService Master");
		this.setResizable(true);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setIconifiable(true);
		this.pack();
		prepareGUI();
		clr();
	}
	
	private void prepareGUI(){
		setLayout(new GridBagLayout());
		gbc=new GridBagConstraints();
		lblheader=new JLabel("SubService Master",JLabel.CENTER);
		lblheader.setFont(new Font("Verdana", Font.BOLD, 18));
		gbc.fill=GridBagConstraints.BOTH;
		addFrmComp(lblheader, 0, 0, 1,1,100,1);		
		cntrlPanel=new JPanel();
		
		addFrmComp(cntrlPanel, 0, 1,1,1, 100,1);
		btnPanel=new JPanel();
		btnPanel.setLayout(new FlowLayout());
		btnAdd=new JButton("Add");			
		btnCancel=new JButton("Cancel");				
		btnClose=new JButton("Close");
		btnEdit=new JButton("Edit");
		btnSave=new JButton("Save");
		btnview=new JButton("view");
		
		addBtnCons(btnAdd,'A',"Add");	
		addBtnCons(btnCancel,'C',"Cancel");
		addBtnCons(btnClose,'l',"Close");
		addBtnCons(btnEdit,'E',"Edit");
		addBtnCons(btnSave,'S',"Save");
		addBtnCons(btnview,'V',"View");
		
		btnPanel.add(btnAdd);
		btnPanel.add(btnSave);
		btnPanel.add(btnEdit);
		btnPanel.add(btnCancel);
		btnPanel.add(btnview);
		btnPanel.add(btnClose);
		
		addFrmComp(btnPanel, 0, 2,1,1, 100,1);
		
		table =new JTable();
		JScrollPane jsrl=new JScrollPane(table);
		addFrmComp(jsrl, 0, 3,1,1, 100,1);		
		lblBottom=new JLabel("Select Row and Press [E] For Edit.",JLabel.CENTER);
		lblBottom.setFont(new Font("Arial", Font.BOLD, 14));
		addFrmComp(lblBottom, 0, 4,1,1, 100,1);
		panel=new JPanel();
		panel.setLayout(new GridBagLayout());		
		cntrlPanel.add(panel);				
		txtSubServicename=new JTextField(20);		
		chkActive=new JCheckBox();
		cboRate =new JComboBox<String>();
		cboService =new JComboBox<String>();
		
		gbc.fill=GridBagConstraints.HORIZONTAL;
		addCompCons(new JLabel("ServiceName : "), 0, 0, 1, 1, 100, 1);
		addCompCons(cboService, 1, 0, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("SubServiceName : "), 0, 1, 1, 1, 100, 1);
		addCompCons(txtSubServicename, 1, 1, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("RateId : "), 0, 2, 1, 1, 100, 1);
		addCompCons(cboRate, 1, 2, 1, 1, 100, 1);
		gbc.fill=GridBagConstraints.HORIZONTAL;		
		addCompCons(new JLabel("Active : "), 0, 3, 1, 1, 100, 1);
		addCompCons(chkActive, 1, 3, 1, 1, 100, 1);
		table.addKeyListener(new actionListner());
		rcrView();
		btnEnab(Actbtn.Deflt);
		clr();
		DispRate();
		DispService();
		btnAdd.requestFocus();		
	}
	private class actionListner implements ActionListener,KeyListener{
		public void actionPerformed(ActionEvent e){
			GetSets gs=new GetSets();
			if (e.getActionCommand().equalsIgnoreCase("Add")){
				cntEnabDisab(true);
				cboService.requestFocus();
				btnEnab(Actbtn.Add);
			}else if (e.getActionCommand().equalsIgnoreCase("Save")){
				if(txtSubServicename.getText().equalsIgnoreCase("")){
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "ServiceMaster",JOptionPane.WARNING_MESSAGE);
					
				}else{
					gs.setSubservm_SubServiceName(txtSubServicename.getText().toString());
					String Service=cboService.getItemAt(cboService.getSelectedIndex()).toString();
					gs.setGen_ServId(Integer.parseInt(Service.substring(Service.indexOf("@")+1)));					
					String rate=cboRate.getItemAt(cboRate.getSelectedIndex()).toString();
					gs.setGen_RateId(Integer.parseInt(rate.substring(rate.indexOf("@")+1)));
					gs.setGen_Active(chkActive.isSelected() ? "Y" : "N");
					if (DBMSubServiceMast.insertSubServiceMast(gs)) {
						JOptionPane.showMessageDialog(null, "Saved.",General.cmpTitle + "SubService Master",1);
						clr();
						rcrView();
						btnEnab(Actbtn.Save);
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Saved.\n" + General.ErrMsg,General.cmpTitle + "SubService Master",0);
					}									
				}				
			}else if (e.getActionCommand().equalsIgnoreCase("Edit")){
				if(txtSubServicename.getText().equalsIgnoreCase("")){
					JOptionPane.showMessageDialog(null, "Please Fill All The Fields.",General.cmpTitle + "SubService Master",JOptionPane.WARNING_MESSAGE);
					
				}else{
					gs.setGen_SubServId(g_SubSerId);
					gs.setSubservm_SubServiceName(txtSubServicename.getText().toString());
					String Service=cboService.getItemAt(cboService.getSelectedIndex()).toString();
					gs.setGen_ServId(Integer.parseInt(Service.substring(Service.indexOf("@")+1)));
					String rate=cboRate.getItemAt(cboRate.getSelectedIndex()).toString();
					gs.setGen_RateId(Integer.parseInt(rate.substring(rate.indexOf("@") +1)));
					gs.setGen_Active(chkActive.isSelected() ? "Y" : "N");
					if (DBMSubServiceMast.updateSubServiceMast(gs)) {
						JOptionPane.showMessageDialog(null, "Edited.",General.cmpTitle + "SubService Master",1);
						clr();
						rcrView();
						btnEnab(Actbtn.Save);
					}else{
						JOptionPane.showMessageDialog(null, "Sorry! Unfortunately Not Edited.\n" + General.ErrMsg,General.cmpTitle + "SubService Master",0);
					}									
				}
			}else if (e.getActionCommand().equalsIgnoreCase("Cancel")){
				clr();
				btnEnab(Actbtn.Cancel);
			}else if (e.getActionCommand().equalsIgnoreCase("View")){
				rcrView();
			}else if (e.getActionCommand().equalsIgnoreCase("Close")){
				dispose();
			}
		}
		public void keyTyped(KeyEvent e){
			
		}
		public void keyPressed(KeyEvent e){			
			if (e.getSource().equals(table)){				
				if (e.getKeyCode() == KeyEvent.VK_E){
					clr();
					cntEnabDisab(true);					
					int selrow=table.getSelectedRow();
					txtSubServicename.setText(table.getValueAt(selrow, 3).toString());
					String Service=table.getValueAt(selrow, 1).toString() + " @" + table.getValueAt(selrow, 0).toString();
					int i;
					for (i=0 ;i < cboService.getItemCount() ; i++){
						if(cboService.getItemAt(i).equalsIgnoreCase(Service)){
							cboService.setSelectedIndex(i);
							break;
						}
					}
					String rateVal=table.getValueAt(selrow, 5).toString() + " @" + table.getValueAt(selrow, 4).toString();
					i=0;
					for (i=0 ;i < cboRate.getItemCount() ; i++){
						if(cboRate.getItemAt(i).equalsIgnoreCase(rateVal)){
							cboRate.setSelectedIndex(i);
							break;
						}
					}
					chkActive.setSelected(table.getValueAt(selrow, 6).toString().equalsIgnoreCase("Y") ? true : false);
					g_SubSerId=Integer.parseInt(table.getValueAt(selrow, 2).toString());
					//System.out.println(g_SubSerId);
					btnEnab(Actbtn.Edit);
					cboService.requestFocus();
				}
			}
		}
		public void keyReleased(KeyEvent e){
			
		}
	}
	public void clr(){
		txtSubServicename.setText("");
		chkActive.setSelected(true);
		if (cboService.getItemCount()>0){
			cboService.setSelectedIndex(0);
		}
		if (cboRate.getItemCount()>0){
			cboRate.setSelectedIndex(0);
		}
		cntEnabDisab(false);
	}
	public void addCompCons(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		panel.add(cmp,gbc);
		
	}
	public void addFrmComp(Component cmp,int r,int col,int w,int h,int wx,int wy){
		gbc.gridx=r;
		gbc.gridy=col;
		gbc.gridwidth=w;
		gbc.gridheight=h;
		gbc.weightx=wx;
		gbc.weighty=wy;
		add(cmp,gbc);
		
	}
	private void addBtnCons(JButton btn,Character mne,String actcmd){
		btn.addActionListener(new actionListner());
		btn.setActionCommand(actcmd);
		btn.setMnemonic(mne);
	}
	private void btnEnab(Actbtn btn){
		switch (btn){
		case Add:
			btnEnabDisab(false, true, false, true, false);
			break;
		case Save:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Edit:
			btnEnabDisab(false, false, true, true, false);			
			break;
		case Cancel:
			btnEnabDisab(true, false, false, true, true);
			break;
		case View:
			btnEnabDisab(true, false, false, true, true);
			break;
		case Deflt:
			btnEnabDisab(true, false, false, true, true);
			break;
		}
	}
	private void btnEnabDisab(Boolean btAdd,Boolean btSave,Boolean btEdit,Boolean btCancel,Boolean btView){
		btnAdd.setEnabled(btAdd);
		btnSave.setEnabled(btSave);
		btnEdit.setEnabled(btEdit);
		btnCancel.setEnabled(btCancel);
		btnview.setEnabled(btView);
	}
	private void cntEnabDisab(Boolean val){
		txtSubServicename.setEnabled(val);
		cboService.setEnabled(val);
		chkActive.setEnabled(val);
		cboRate.setEnabled(val);
	}
	private void rcrView(){		
		String operClm[]={"ServId","ServiceName","SubServId","SubServiceName","RateId","Rate","Active"};
		ArrayList<Object[]> data=new ArrayList<Object[]>();				
		data=DBMSubServiceMast.viewSubService();				
		Object[][] realData=data.toArray(new Object[data.size()][]);				
		table.setBorder(new LineBorder(new Color(0,0,0)));
		table.setModel(new DefaultTableModel(realData,operClm){
			private static final long serialVersionUID = 1L;		
			public boolean isCellEditable(int row,int column){return false;}
		});
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);				
	}
	private void DispRate(){
		ArrayList<String> data=new ArrayList<String>();
		data=DBMSubServiceMast.disprate();		
		for(String el : data){
			cboRate.addItem(el.toString());
		}		
	}
	private void DispService(){
		ArrayList<String> data=new ArrayList<String>();
		data=DBMSubServiceMast.dispService();		
		for(String el : data){
			cboService.addItem(el.toString());
		}		
	}

}

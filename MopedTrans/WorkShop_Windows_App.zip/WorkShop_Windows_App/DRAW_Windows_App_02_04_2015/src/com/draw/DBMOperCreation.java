package com.draw;


import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class DBMOperCreation extends General {
	
	public static Boolean insertOperator(GetSets set) {						
		try {			
			dbmConOpen();
			Strsql="INSERT INTO `operator`(`FirstName`,`LastName`,`userName`,`Password`,`Active`)" ;
			Strsql = Strsql + " VALUES(?,?,?,?,?)";
			PreparedStatement stmt=conn.prepareStatement(Strsql);			
			stmt.setString(1, set.getOper_FirstName());
			stmt.setString(2, set.getOper_LastName());
			stmt.setString(3, set.getOper_userName());
			stmt.setString(4, set.getOper_Password());
			stmt.setString(5, set.getGen_Active());
			stmt.execute();
			return true;
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			General.ErrMsg=e.getMessage().toString();
			return false;
		}finally{
			ConnectionManager.getInstance().closeConnection();
		}
		
	}
	
	public static Boolean updateOperator(GetSets set){								
		try {
			dbmConOpen();
			Strsql="update `operator` set `FirstName`=?,`LastName`=?,`userName`=?,`Password`=?,`Active`=?,`Last_Updated`=? where `OperId`=?" ;
			PreparedStatement stmt=conn.prepareStatement(Strsql);			
			stmt.setString(1, set.getOper_FirstName());
			stmt.setString(2, set.getOper_LastName());
			stmt.setString(3, set.getOper_userName());
			stmt.setString(4, set.getOper_Password());
			stmt.setString(5, set.getGen_Active());
			stmt.setDate(6, serv_Date);
			stmt.setLong(7, set.getGen_OperId());
			System.out.println(set.getGen_OperId());
			stmt.execute();			
			return true;
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			General.ErrMsg=e.getMessage().toString();
			return false;
		}finally{
			ConnectionManager.getInstance().closeConnection();
		}		
	}
	public static ArrayList<Object[]> viewOperator(){
		ArrayList<Object[]> data=new ArrayList<Object[]>();
		dbmConOpen();		
		try {
			Strsql="select OperId,FirstName,LastName,UserName,Active,`Password` from Operator order by OperId";
			stmt=conn.createStatement();
			rs=stmt.executeQuery(Strsql);
			while (rs.next()){
				//System.out.println("in s whi");
				Object[] row=new Object[]{rs.getInt(1),
						rs.getString(2),
						rs.getString(3),
						rs.getString(4),
						rs.getString(5),
						rs.getString(6)};
				data.add(row);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), General.cmpTitle + "OperCreation", 0);
		}finally{
			try {
				rs.close();
				stmt.close();
				ConnectionManager.getInstance().closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		//System.out.println(data.toString());
		return data;
	}
	
}

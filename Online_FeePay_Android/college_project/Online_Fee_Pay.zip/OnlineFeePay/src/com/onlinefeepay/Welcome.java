package com.onlinefeepay;

import com.onlinefeepay.R;
import com.parse.ParseInstallation;
import com.parse.ParsePush;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Welcome extends Activity {
	
	// Declare Variable
	Button logout;
	Button userCreation;
	Button butParentAccCreation;
	String usertype="";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		// Get the view from singleitemview.xml
		setContentView(R.layout.welcome);
		
		// Retrieve current user from Parse.com
		ParseUser currentUser = ParseUser.getCurrentUser();
		
		// Convert currentUser into String
		String struser = currentUser.getUsername().toString();
		
		if(currentUser.get("usertype")!=null){
			usertype=currentUser.get("usertype").toString();
		}
		
		// Locate TextView in welcome.xml
		TextView txtuser = (TextView) findViewById(R.id.txtuser);

		// Set the currentUser String into TextView
		txtuser.setText("You are logged in as " + struser);
		
		
		userCreation = (Button) findViewById(R.id.butUserCreation);
		userCreation.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(Welcome.this,UserCreation.class);
				startActivity(intent);
				//finish();
				
			}
		});
		
		butParentAccCreation = (Button) findViewById(R.id.butParentAccCreation);
		butParentAccCreation.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(Welcome.this,ParentCreation.class);
				startActivity(intent);
				//finish();
				
			}
		});
		
		Button butCreateFees = (Button) findViewById(R.id.butCreateFees);
		butCreateFees.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(Welcome.this,CreateExamFees.class);
				startActivity(intent);
				
				
			}
		});
		
		Button butFeepay = (Button) findViewById(R.id.butFeepay);
		butFeepay.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(Welcome.this,FeePay.class);
				startActivity(intent);
				
				
			}
		});
		
		Button butbankAccountCreation = (Button) findViewById(R.id.butbankAccountCreation);
		butbankAccountCreation.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(Welcome.this,BankAccountCreation.class);
				startActivity(intent);
				
				
			}
		});
		
		Button butGenerateExamFees = (Button) findViewById(R.id.butGenerateExamFees);
		butGenerateExamFees.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(Welcome.this,CircularGenerate.class);
				startActivity(intent);
				
				
			}
		});
		
		Button butViewStstus = (Button) findViewById(R.id.butViewStstus);
		butViewStstus.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(Welcome.this,StatusView.class);
				startActivity(intent);
            	
            	//Toast.makeText(getApplicationContext(), "Saved, Fee ID: " + (++ Util.feeid ), Toast.LENGTH_SHORT).show();
				
				
			}
		});
		
		Button butChangePassword = (Button) findViewById(R.id.butChangePassword);
		butChangePassword.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(Welcome.this,PasswordChange.class);
				startActivity(intent);
				
				
			}
		});

		// Locate Button in welcome.xml
		logout = (Button) findViewById(R.id.logout);
		// Logout Button Click Listener
		logout.setOnClickListener(new OnClickListener() {

			public void onClick(View arg0) {
				// Logout current user
				ParseUser.logOut();
				finish();
			}
		});
		
		
		//Button butEditUser = (Button) findViewById(R.id.butEditUser);
		Button butviewEditUser = (Button) findViewById(R.id.butviewEditUser);		
		Util.studRegNo="";
		
		if(usertype.equalsIgnoreCase("student")){
			Util.studRegNo=ParseUser.getCurrentUser().getString("registerno");
			Util.isStudent=true;
			butGenerateExamFees.setEnabled(false);
			userCreation.setEnabled(false);
			//butEditUser.setEnabled(false);
			butviewEditUser.setEnabled(false);
			butbankAccountCreation.setEnabled(false);
			butCreateFees.setEnabled(false);
			butParentAccCreation.setEnabled(false);
			
		}else if(usertype.equalsIgnoreCase("parent")){
			Util.studRegNo=ParseUser.getCurrentUser().getString("registerno");
			Util.isParent=true;
			butGenerateExamFees.setEnabled(false);
			userCreation.setEnabled(false);
			//butEditUser.setEnabled(false);
			butviewEditUser.setEnabled(false);
			butbankAccountCreation.setEnabled(false);
			butCreateFees.setEnabled(false);
			butParentAccCreation.setEnabled(false);
			butFeepay.setEnabled(false);
		}
	}
}
package com.onlinefeepay;

public class Util {
	public static int feeid=0;
	public static boolean isStudent=false;
	public static boolean isParent=false;
	public static String studRegNo="";
}

package com.onlinefeepay;

public class UserList {
	
	String objId;
	String RegNo;
	String Name;	
	String Course;
	String Branch;
	String batch;
	
	public UserList(String objId,String RegNo,String Name,String Course,String Branch,String batch){
		this.objId=objId;
		this.RegNo=RegNo;
		this.Name=Name;
		this.Course=Course;
		this.Branch=Branch;
		this.batch=batch;
	}
	
	
	public String getBatch() {
		return batch;
	}


	public void setBatch(String batch) {
		this.batch = batch;
	}


	public String getObjId() {
		return objId;
	}

	public void setObjId(String objId) {
		this.objId = objId;
	}

	public String getRegNo() {
		return RegNo;
	}
	public void setRegNo(String regNo) {
		RegNo = regNo;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getCourse() {
		return Course;
	}
	public void setCourse(String course) {
		Course = course;
	}
	public String getBranch() {
		return Branch;
	}
	public void setBranch(String branch) {
		Branch = branch;
	}
	
	

}

package com.onlinefeepay;

public class Config {

	public static String pass;
}

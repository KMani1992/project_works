package com.onlinefeepay;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;

public class PasswordChange   extends Activity{
	
	
	Button butChangePwd;
	EditText editoldPassword;
	EditText editTxtNewPassword;	
	String id;
	
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.pwdchange);
		
		
		editoldPassword = (EditText) findViewById(R.id.editoldPassword);
		editTxtNewPassword = (EditText) findViewById(R.id.editTxtNewPassword);
		
		butChangePwd=(Button) findViewById(R.id.butChangePwd);
		
		butChangePwd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				ParseObject obj=new ParseObject("user");
				obj.put("password",editTxtNewPassword.getText().toString());
				obj.saveInBackground(new SaveCallback() {
					
					@Override
					public void done(ParseException e) {
						// TODO Auto-generated method stub
						
						if(e==null){
							Toast.makeText(
									getApplicationContext(),
									"Password Changed",
									Toast.LENGTH_SHORT).show();
							
						}else{
							Toast.makeText(
									getApplicationContext(),
									"Failed, Password Not Changed",
									Toast.LENGTH_SHORT).show();
						}
						
					}
				});
				
			}
		});
		
//		butChangePwd.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				
//				
//				// update post				
//				ParseQuery<ParseObject> query = ParseQuery.getQuery("user");
//				 
//				Log.d("msg ", "parse");
//				
//				// Retrieve the object by id
//				query.getInBackground(ParseUser.getCurrentUser().getUsername().toString(), new GetCallback<ParseObject>() {
//				  
//					public void done(ParseObject post, ParseException e) {
//					  
//					  Log.d("msg ", "test top");
//					  
//					  //if (e == null) {
//							Log.d("msg ", "test 1");
//						//	String oldpass = post.get("objectId").toString();
//									
//							//String oldpass=ParseUser.getCurrentUser().get("password").toString();
//							 Log.d("msg ", "test top111 "  + Config.pass);
//							 
////							if (Config.pass.equals(editoldPassword.getText()
////									.toString())) {
//								Log.d("msg ", "test top111 be "  );
//								// Now let's update it with some new data.
//								post.put("password", editTxtNewPassword
//										.getText().toString());
//
//								setProgressBarIndeterminateVisibility(true);
//								Log.d("msg ", "test top111 ae "  );
//								post.saveInBackground(new SaveCallback() {
//									public void done(ParseException e) {
//										setProgressBarIndeterminateVisibility(false);
//										if (e == null) {
//											// Saved successfully.
//											Toast.makeText(
//													getApplicationContext(),
//													"Password Changed",
//													Toast.LENGTH_SHORT).show();
//										} else {
//											// The save failed.
//											Toast.makeText(
//													getApplicationContext(),
//													"Failed to Save",
//													Toast.LENGTH_SHORT).show();
//											Log.d(getClass().getSimpleName(),
//													"User update error: " + e);
//										}
//									}
//								});
////							} else {
////								Toast.makeText(getApplicationContext(),
////										"Please Check Old Password",
////										Toast.LENGTH_SHORT).show();
////							}
//				    //}
//				  }
//				});
//		
//			}
//		
//	});
		
	}
}

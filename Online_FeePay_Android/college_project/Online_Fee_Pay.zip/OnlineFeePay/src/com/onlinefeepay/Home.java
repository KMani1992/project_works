package com.onlinefeepay;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class Home extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		
		setContentView(R.layout.home);
		Thread back=new Thread(){
			public void run(){
			
				try{
					sleep(5*1000);
				}catch(Exception e){
					e.printStackTrace();
				}
				Intent intent = new Intent(
						Home.this,
						MainActivity.class);
				startActivity(intent);
				finish();
			}
		};
		back.start();
	}
	
	

}

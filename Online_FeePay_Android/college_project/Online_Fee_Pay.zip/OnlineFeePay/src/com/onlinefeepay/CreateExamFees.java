package com.onlinefeepay;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParsePush;
import com.parse.ParseUser;
import com.parse.SaveCallback;
import com.parse.SignUpCallback;

public class CreateExamFees extends Activity{
	
	
	Button butexamfeeSave;
	EditText editTxtSemester;
	EditText edittxtmonthandyear;
	EditText edittxtAmount;
	EditText editTxtDepositBankAcc;
	EditText editTxtLastDate;
	EditText editTxtexfeeidcre;
	

	
	
	
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.createexamfees);
		
		
		editTxtSemester = (EditText) findViewById(R.id.editTxtSemester);
		edittxtmonthandyear = (EditText) findViewById(R.id.edittxtmonthandyear);
		edittxtAmount = (EditText) findViewById(R.id.edittxtAmount);
		editTxtDepositBankAcc= (EditText) findViewById(R.id.editTxtDepositBankAcc);
		editTxtLastDate= (EditText) findViewById(R.id.editTxtLastDate);
		editTxtexfeeidcre=(EditText)findViewById(R.id.editTxtexfeeidcre);
		
		butexamfeeSave=(Button) findViewById(R.id.butexamfeeSave);
		
		butexamfeeSave.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				
				ParseObject objexamfee=new ParseObject("semesterfee");
				
				String sem=editTxtSemester.getText().toString();
				String month=edittxtmonthandyear.getText().toString();
				String amount=edittxtAmount.getText().toString();
				String depos=editTxtDepositBankAcc.getText().toString();
				String lastDate=editTxtLastDate.getText().toString();
				final String  exfeeid=editTxtexfeeidcre.getText().toString();
				
				objexamfee.put("semester",sem);
				objexamfee.put("monthandyear",month);
				objexamfee.put("amount",amount);
				objexamfee.put("depositbankacc",depos);
				objexamfee.put("lastdate",lastDate);
				objexamfee.put("feeid",exfeeid);
				
				
				setProgressBarIndeterminateVisibility(true);
				
				objexamfee.saveInBackground(new SaveCallback() {
		            public void done(ParseException e) {
		            	setProgressBarIndeterminateVisibility(false);
		                if (e == null) {
		                    // Saved successfully.
		                	
		                	
		                	Toast.makeText(getApplicationContext(), "Saved, Fee ID: " + (exfeeid), Toast.LENGTH_SHORT).show();
		                } else {
		                    // The save failed.
		                	Toast.makeText(getApplicationContext(), "Exam Fee Not Created", Toast.LENGTH_SHORT).show();
		                    Log.d(getClass().getSimpleName(), "Examfee update error: " + e);
		                }
		            }
		        });
		
			}
		
	});
		
	}
}

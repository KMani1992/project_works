package com.onlinefeepay;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract.CommonDataKinds.Note;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseInstallation;
import com.parse.ParseObject;
import com.parse.ParsePush;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;

public class CircularGenerate   extends Activity{
	
	
	Button but_gen_exam_fee_cirul;
	Button but_genfee_all;
	
	EditText edittxtfeeID;
	String id;
	String amount;
	List<UserList> userlist=null;
	List<ParseObject> ob;
	List<ParseUser> pus;
	ListView lstv;
	
	
	
	String usrName = "";								
	String batch= "";
	String branch= "";
	String course= "";
	String amountlo= "";
	String semester= "";
	String status= "";
	String regno= "";
	String monyr="";
	String lstdt="";
	
	
	ProgressDialog mProgressDialog;
	//ArrayAdapter<String> adaptera;
	ArrayAdapter<String> adapter ;
	
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.createcircular);
		
		
		
		edittxtfeeID=(EditText) findViewById(R.id.edittxtfeeID);
		
		
		
		//refreshUserList();
		//new RemoteDataTask().execute();
		ref();		
		
		
		
		but_gen_exam_fee_cirul=(Button) findViewById(R.id.but_gen_exam_fee_cirul);
		but_genfee_all=(Button)findViewById(R.id.but_genfee_all);
		
	
		
		but_gen_exam_fee_cirul.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				amountlo= "1200";
				semester= "4";
				monyr="Mar 2016";
				lstdt="25-Feb-2016";
				
				ParseQuery<ParseObject> query = new ParseQuery<ParseObject>(
						"semesterfee");
						
				//Toast.makeText(getApplicationContext(), "Fid " + edittxtfeeID.getText().toString(), Toast.LENGTH_SHORT).show();
				
				if(edittxtfeeID.getText().toString()!=""){		
					
					query.whereEqualTo("feeid", edittxtfeeID.getText().toString());
					
				}
						
						
						
						query.findInBackground(new FindCallback<ParseObject>() {

							@Override
							public void done(List<ParseObject> objects, ParseException e) {
								// TODO Auto-generated method stub
								
								//Toast.makeText(getApplicationContext(), "top " + objects.size(), Toast.LENGTH_SHORT).show();
								
								if(e==null){
								
									//Toast.makeText(getApplicationContext(), "Fsi" + objects.size(), Toast.LENGTH_SHORT).show();
									
								if(objects.size()>0){
									ParseObject objf=objects.get(0);
								
								amountlo =objf.getString("amount");
								semester=objf.getString("semester");
								monyr=objf.getString("monthandyear");
								lstdt=objf.getString("lastdate");
								
								}
								
								}else{
									Toast.makeText(getApplicationContext(), "Fail to Load", Toast.LENGTH_SHORT).show();	
								}
								
							}
						});
				
				
				//ParseQuery<ParseObject> query = ParseQuery.getQuery("semesterfee");
				
				//query.whereEqualTo("feeid", edittxtfeeID.getText().toString());
				
				
				setProgressBarIndeterminateVisibility(true);
				
				
				// Retrieve the object by id
//				query.getInBackground(edittxtfeeID.getText().toString(), new GetCallback<ParseObject>() {
//				  public void done(ParseObject post, ParseException e) {
//				    if (e == null) {
//				      // Now let's update it with some new data.
//				    	amount = post.getString("amount");
//				    							
//						
//						
//				    }
//				  }
//				});
//				
				
				
				
				ParseObject objexamfee=new ParseObject("examfee");
				
				
//				userlist.add(new UserList("1", "1223", "Mani", "B.E", "CSE", "2016"));
//				userlist.add(new UserList("2", "1224", "Raju", "B.E", "CSE", "2016"));
//				userlist.add(new UserList("3", "1225", "Viji", "B.E", "CSE", "2016"));
//				userlist.add(new UserList("1", "1223", "Barani", "B.E", "CSE", "2016"));
//				userlist.add(new UserList("1", "1223", "Mani", "B.E", "CSE", "2016"));
//				userlist.add(new UserList("1", "1223", "Mani", "B.E", "CSE", "2016"));
				
				for (UserList lst : userlist){
					
					objexamfee.put("studregno",lst.getRegNo());
					objexamfee.put("course",lst.getCourse());
					objexamfee.put("batch",lst.getBatch());
					objexamfee.put("branch",lst.getBranch());		
					objexamfee.put("amount",amountlo);
					objexamfee.put("semester",semester);
					objexamfee.put("monyr",monyr);
					
				}
				
				
				setProgressBarIndeterminateVisibility(true);
				
				objexamfee.saveInBackground(new SaveCallback() {
		            public void done(ParseException e) {
		            	setProgressBarIndeterminateVisibility(false);
		                if (e == null) {
		                    // Saved successfully.
		                	
		    				try{
		    					
		    	            	String Msg="Your Exam Fee for " + monyr + " " + semester + " sem is Rs " + amountlo + ", Last Dt to pay " + lstdt ;
		    					ParseQuery<ParseInstallation> query = ParseInstallation.getQuery(); 
		    					query.whereEqualTo("device_id", "1234567890");
		    					ParsePush.sendMessageInBackground(Msg, query);
		    					
		    					
		    				}catch(Exception ex){
		    					ex.printStackTrace();
		    				}
		                	
		                	
		                	Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_SHORT).show();
		                } else {
		                    // The save failed.
		                	Toast.makeText(getApplicationContext(), "Exam Fee Not Created", Toast.LENGTH_SHORT).show();
		                    Log.d(getClass().getSimpleName(), "Examfee update error: " + e);
		                }
		            }
		        });
		
			}
		
	});
		
		
	}
	
		
	private void refreshUserList() {

		ParseQuery<ParseObject> query = ParseQuery.getQuery("user");
		
		query.whereEqualTo("usertype", "student");

		setProgressBarIndeterminateVisibility(true);

		query.findInBackground(new FindCallback<ParseObject>() {

			@SuppressWarnings("unchecked")
			@Override
			public void done(List<ParseObject> postList, ParseException e) {
				setProgressBarIndeterminateVisibility(false);
				//if (e == null) {
					// If there are results, update the list of posts
					// and notify the adapter
					userlist.clear();
					for (ParseObject post : postList) {
						UserList note = new UserList(post.getObjectId(), 
								post.getString("registerno"), post.getString("username"),post.getString("course"),post.getString("branch"),post.getString("batch"));
						userlist.add(note);
					}
					
					//((ArrayAdapter<UserList>) getListAdapter()).notifyDataSetChanged();
		
//				} else {
//
//					Log.d(getClass().getSimpleName(), "Error: " + e.getMessage());
//				}

			}

		});

	
}
	
	
	private void ref(){
		
		Toast.makeText(getApplicationContext(), "Loading ...Please Wait", Toast.LENGTH_SHORT).show();
		
		ParseQuery<ParseUser> us=ParseUser.getQuery();
		
		us.whereEqualTo("usertype", "student");
		
		
		
		// Locate the listview in listview_main.xml
		lstv = (ListView) findViewById(R.id.listviewcir);
		//String []value= String ();
		
		
		final List<String> val=new ArrayList<String>();
		
		// Pass the results into an ArrayAdapter
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(CircularGenerate.this, android.R.layout.simple_list_item_1,android.R.id.text1,val);
		
		
		
		userlist = new ArrayList<UserList>();
		
		userlist.clear();
		
		us.findInBackground(new FindCallback<ParseUser>() {

			@Override
			public void done(List<ParseUser> objects, ParseException e) {
				// TODO Auto-generated method stub
				
				if (e==null){
					
					Toast.makeText(getApplicationContext(), "Success", Toast.LENGTH_SHORT).show();
					String a = null;
					ParseObject obj;
					
					for (int i=0;i<objects.size();i++){
						obj=objects.get(i);
						
						//a +=   obj.getString("batch");
						
						usrName = "";								
						batch= "";
						branch= "";
						course= "";
						regno= "";
						
						
						regno=obj.getString("registerno");
						usrName= obj.getString("username");
						course=obj.getString("course");
						branch=obj.getString("branch");
						batch=obj.getString("batch");
						
						UserList note = new UserList(obj.getObjectId(),
								regno, usrName,course,branch,batch);
						userlist.add(note);
						
						val.add(regno + ", " + usrName + ", " + course + ", " + branch + ", " + batch);
						
					}
					
					Toast.makeText(getApplicationContext(), "Loaded", Toast.LENGTH_SHORT).show();
					
				}else{
					
					Toast.makeText(getApplicationContext(), "Fail to Load", Toast.LENGTH_SHORT).show();
					
				}
				
			}
		});
//		
//		
		
//		
//		val.add("Barani,2 Yr,3rd sem");
//		val.add("Malar,2 Yr,3rd sem");
//		val.add("Mani,2 Yr,3rd sem");
//		val.add("Raja,2 Yr,3rd sem");
//		val.add("Raju,2 Yr,3rd sem");
//		val.add("Viji,2 Yr,3rd sem");			
//		
		
		
		
		
//		for (ParseObject post : ob) {
//			UserList note = new UserList(post.getObjectId(), 
//					post.getString("registerno"), post.getString("username"),post.getString("course"),post.getString("branch"),post.getString("batch"));
//			userlist.add(note);
//		}
	
		// Binds the Adapter to the ListView
		lstv.setAdapter(adapter);
		
		// Close the progressdialog
		//mProgressDialog.dismiss();
		
		
		
		
		
		
		
		//qry.findInBackground(new FindCallback<ParseObject>() {

		//	@Override
//			public void done(List<ParseObject> objects, ParseException e) {
//				// TODO Auto-generated method stub
//				
//				if (e==null){
//					
//					Toast.makeText(getApplicationContext(), "Success", Toast.LENGTH_SHORT).show();
//					String a = null;
//					ParseObject obj;
//					
//					for (int i=0;i<objects.size();i++){
//						obj=objects.get(i);
//						
//						a +=   obj.getString("branch");
//						
//					}
//					
//					Toast.makeText(getApplicationContext(), a, Toast.LENGTH_SHORT).show();
//					
//				}else{
//					
//					Toast.makeText(getApplicationContext(), "Fail", Toast.LENGTH_SHORT).show();
//					
//				}
//				
//			}
//			
//			
//		});
		
	}
	
	// RemoteDataTask AsyncTask
		private class RemoteDataTask extends AsyncTask<Void, Void, Void> {
			ParseQuery<ParseUser> us;
			ParseQuery<ParseObject> query;
			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				// Create a progressdialog
				mProgressDialog = new ProgressDialog(CircularGenerate.this);
				// Set progressdialog title
				mProgressDialog.setTitle("Fetching User Info");
				// Set progressdialog message
				mProgressDialog.setMessage("Loading...");
				mProgressDialog.setIndeterminate(false);
				// Show progressdialog
				mProgressDialog.show();
			}

			@Override
			protected Void doInBackground(Void... params) {
				// Locate the class table named "Country" in Parse.com
				us=ParseUser.getQuery();
				
//				query = new ParseQuery<ParseObject>(
//						"semesterfee");
				//query.whereEqualTo("feeid", edittxtfeeID.getText().toString());
				//query.orderByDescending("_created_at");
				try {
					//us.whereEqualTo("usertype", "student");
					//query.whereEqualTo("feeid", edittxtfeeID.getText().toString());
					//ob = us.find();
				} catch (Exception e) {
					Log.e("Error", e.getMessage());
					e.printStackTrace();
				}
				
				us.findInBackground(new FindCallback<ParseUser>() {

					@Override
					public void done(List<ParseUser> objects, ParseException e) {
						// TODO Auto-generated method stub
						pus=objects;
					}
				});
				
//				query.findInBackground(new FindCallback<ParseObject>() {
//
//					@Override
//					public void done(List<ParseObject> objects, ParseException e) {
//						// TODO Auto-generated method stub
//						
//						ob=objects;
//						
//					}
//				});
				
				
				
				return null;
			}

			@Override
			protected void onPostExecute(Void result) {
				// Locate the listview in listview_main.xml
				lstv = (ListView) findViewById(R.id.listviewcir);
				//String []value= String ();
				
				
				List<String> val=new ArrayList<String>();
				
				// Pass the results into an ArrayAdapter
				ArrayAdapter<String> adapter = new ArrayAdapter<String>(CircularGenerate.this, android.R.layout.simple_list_item_1,android.R.id.text1,val);
				
				
				
				userlist = new ArrayList<UserList>();
				
				userlist.clear();
				val.clear();
				
				String usrName = null;								
				String batch;
				String branch;
				String course;
				String amount;
				String semester;
				String status;
				String regno;
				
				
				ParseObject obj;
				
				if(pus!=null){
				for (int i=0;i<pus.size();i++){
					obj=pus.get(i);
					
					//a +=   obj.getString("batch");					
					
					regno=obj.getString("registerno");
					usrName= obj.getString("username");
					course=obj.getString("course");
					branch=obj.getString("branch");
					batch=obj.getString("batch");
					
					UserList note = new UserList(obj.getObjectId(),
							regno, usrName,course,branch,batch);
					userlist.add(note);
					
					val.add(regno + ", " + usrName + ", " + course + ", " + branch + ", " + batch);
					
				}
				}
				
//				// Retrieve object "name" from Parse.com database
//				for (ParseUser user : pus) {
//					//adapter.add((String) country.get("name"));
//					//val.add((String) user.get("username"));
//					//val.add(user.getString("username"));
//					usrName=user.getString("username");
//					
//					
//				}
				
//				for (int i=0;i<pus.size();i++){
//					ParseObject obj=pus.get(i);
//					
//					usrName +=   obj.getString("batch");
//					
//				}
				
				//Toast.makeText(getApplicationContext(), usrName, Toast.LENGTH_SHORT).show();
				
//				for (int i=0;i<ob.size();i++){
//					ParseObject ws=ob.get(i);
//					val.add(ws.getString("username"));
//				}
				
//				val.add("Barani,2 Yr,3rd sem");
//				val.add("Malar,2 Yr,3rd sem");
//				val.add("Mani,2 Yr,3rd sem");
//				val.add("Raja,2 Yr,3rd sem");
//				val.add("Raju,2 Yr,3rd sem");
//				val.add("Viji,2 Yr,3rd sem");			
				
				
				
				
				
//				for (ParseObject post : ob) {
//					UserList note = new UserList(post.getObjectId(), 
//							post.getString("registerno"), post.getString("username"),post.getString("course"),post.getString("branch"),post.getString("batch"));
//					userlist.add(note);
//				}
			
				// Binds the Adapter to the ListView
				lstv.setAdapter(adapter);
				
				// Close the progressdialog
				mProgressDialog.dismiss();
				
				
			}
		}
	
		
		
		
		

		
	
}

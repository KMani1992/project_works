package com.onlinefeepay;

import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.SaveCallback;

public class FeePay  extends Activity{
	
	
	Button butfeepaySave;
	EditText editTxtfeepayRegNo;
	EditText editTxtfeepaySemester;
	EditText edittxtfeepaymonthandyear;
	EditText edittxtfeepayAmount;
	EditText editTxtFromAcc;
	EditText editTxtToBankAcc;
	String id;
	
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.feepay);
		
		
		editTxtfeepayRegNo = (EditText) findViewById(R.id.editTxtfeepayRegNo);
		editTxtfeepaySemester = (EditText) findViewById(R.id.editTxtfeepaySemester);
		edittxtfeepaymonthandyear = (EditText) findViewById(R.id.edittxtfeepaymonthandyear);
		edittxtfeepayAmount = (EditText) findViewById(R.id.edittxtfeepayAmount);
		editTxtFromAcc = (EditText) findViewById(R.id.editTxtFromAcc);
		editTxtToBankAcc = (EditText) findViewById(R.id.editTxtToBankAcc);
		
		editTxtfeepayRegNo.setText(GetSet.getRegNo());
		editTxtfeepaySemester.setText(GetSet.getSem());
		edittxtfeepaymonthandyear.setText(GetSet.getMonth());
		edittxtfeepayAmount.setText(GetSet.getAmount());
		editTxtFromAcc.setText("IOB - 26361010002345");
		editTxtToBankAcc.setText("HDFC - 86361010003264");
		editTxtToBankAcc.setText(GetSet.getAccno());
		
		butfeepaySave=(Button) findViewById(R.id.butfeepaySave);
		
		butfeepaySave.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Toast.makeText(getApplicationContext(), "Updating ...Please Wait " + GetSet.getRegNo(), Toast.LENGTH_SHORT).show();
// update post
				
				ParseQuery<ParseObject> query = ParseQuery.getQuery("examfee");
				//ParseQuery<ParseObject> query = ParseQuery.getQuery("Post");
				
			    query.whereEqualTo("studregno", GetSet.getRegNo());
				
				id=GetSet.getObjId();
				 
				
				//Toast.makeText(getApplicationContext(), id, Toast.LENGTH_SHORT).show();
				
				
				query.findInBackground(new FindCallback<ParseObject>() {

					@Override
					public void done(List<ParseObject> arg0, ParseException arg1) {
						// TODO Auto-generated method stub
						
						if(arg1==null){
							
							ParseObject pobj=arg0.get(0);
							
							pobj.put("status", "Paid");
							
							pobj.saveInBackground();
							
							//setProgressBarIndeterminateVisibility(true);
//							pobj.saveInBackground(new SaveCallback() {
//					            public void done(ParseException e) {
//					            	//setProgressBarIndeterminateVisibility(false);
//					                if (e == null) {
//					                    // Saved successfully.
//					                	Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_SHORT).show();
//					                } else {
//					                    // The save failed.
//					                	Toast.makeText(getApplicationContext(), "Failed to Save", Toast.LENGTH_SHORT).show();
//					                    Log.d(getClass().getSimpleName(), "User update error: " + e);
//					                }
//					            }
//					        });
						}else{
							Toast.makeText(getApplicationContext(), "Not Paid,Please Check The Details", Toast.LENGTH_SHORT).show();
						}
							
						Toast.makeText(getApplicationContext(), "Paid", Toast.LENGTH_SHORT).show();
						
					}
					
				});
				
//				query.getFirstInBackground(new GetCallback<ParseObject>() {
//
//					@Override
//					public void done(ParseObject object, ParseException e) {
//						// TODO Auto-generated method stub
//						
//						if(e==null){
//							
//							object.put("status", "Paid");
//							
//							object.saveInBackground(new SaveCallback() {
//					            
//								public void done(ParseException e) {
//					            	//setProgressBarIndeterminateVisibility(false);
//					                if (e == null) {
//					                    // Saved successfully.
//					                	Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_SHORT).show();
//					                } else {
//					                    // The save failed.
//					                	Toast.makeText(getApplicationContext(), "Failed to Save", Toast.LENGTH_SHORT).show();
//					                    Log.d(getClass().getSimpleName(), "User update error: " + e);
//					                }
//					            }
//								
//					        });
//						}
//						
//					}
//					
//				});
				
				
//				// Retrieve the object by id
//				query.getInBackground(id, new GetCallback<ParseObject>() {
//				  public void done(ParseObject post, ParseException e) {
//				    if (e == null) {
//				      // Now let's update it with some new data.
//				    	post.put("status", "Paid");
//						
//						setProgressBarIndeterminateVisibility(true);
//						post.saveInBackground(new SaveCallback() {
//				            public void done(ParseException e) {
//				            	setProgressBarIndeterminateVisibility(false);
//				                if (e == null) {
//				                    // Saved successfully.
//				                	Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_SHORT).show();
//				                } else {
//				                    // The save failed.
//				                	Toast.makeText(getApplicationContext(), "Failed to Save", Toast.LENGTH_SHORT).show();
//				                    Log.d(getClass().getSimpleName(), "User update error: " + e);
//				                }
//				            }
//				        });
//				    }
//				  }
//				});
		
			}
		
	});
		
	}
}

package com.onlinefeepay;

import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.SaveCallback;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class BankAccountCreation extends Activity{
	
	
	Button butCreateAccount;
	EditText editTxtAccountHolder;
	EditText editbacctxtRegNo;
	EditText editTxtBankName;
	EditText editTxtAccountNo;
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.bankaccount);
		
		
		editTxtAccountHolder = (EditText) findViewById(R.id.editTxtAccountHolder);
		editbacctxtRegNo = (EditText) findViewById(R.id.editbacctxtRegNo);
		editTxtBankName = (EditText) findViewById(R.id.editTxtBankName);
		editTxtAccountNo = (EditText) findViewById(R.id.editTxtAccountNo);
		
		butCreateAccount=(Button) findViewById(R.id.butCreateAccount);
		
		butCreateAccount.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				
				ParseObject objexamfee=new ParseObject("bankacc");
				
				
				objexamfee.put("accholder",editTxtAccountHolder.getText().toString());
				objexamfee.put("studregno",editbacctxtRegNo.getText().toString());
				objexamfee.put("bankname",editTxtBankName.getText().toString());
				objexamfee.put("accountno",editTxtAccountNo.getText().toString());
				
				
				setProgressBarIndeterminateVisibility(true);
				
				objexamfee.saveInBackground(new SaveCallback() {
		            public void done(ParseException e) {
		            	setProgressBarIndeterminateVisibility(false);
		                if (e == null) {
		                    // Saved successfully.
		                	
		                	Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_SHORT).show();
		                } else {
		                    // The save failed.
		                	Toast.makeText(getApplicationContext(), "Bank Account Not Created", Toast.LENGTH_SHORT).show();
		                    Log.d(getClass().getSimpleName(), "BankAccount update error: " + e);
		                }
		            }
		        });
		
			}
		
	});
		
	}
}

package com.onlinefeepay;

import android.R.string;

public class GetSet {
	
	private static String Sem;
	private static String month;
	private static String amount;
	private static String accno;
	private static String RegNo;
	private static String objId;
	
	public static String getObjId() {
		return objId;
	}
	public static void setObjId(String objId) {
		GetSet.objId = objId;
	}
	public static String getRegNo() {
		return RegNo;
	}
	public static void setRegNo(String regNo) {
		RegNo = regNo;
	}
	public static String getAccno() {
		return accno;
	}
	public static void setAccno(String accno) {
		GetSet.accno = accno;
	}
	public static String getSem() {
		return Sem;
	}
	public static void setSem(String sem) {
		Sem = sem;
	}
	public static String getMonth() {
		return month;
	}
	public static void setMonth(String month) {
		GetSet.month = month;
	}
	public static String getAmount() {
		return amount;
	}
	public static void setAmount(String amount) {
		GetSet.amount = amount;
	}
	
	
	
	

}

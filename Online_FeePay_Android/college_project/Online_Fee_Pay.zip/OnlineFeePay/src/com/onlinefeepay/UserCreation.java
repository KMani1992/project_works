package com.onlinefeepay;


import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserCreation extends Activity  {

	Button butsaveUser;
	EditText editTxtUserName;
	EditText editTxtparentpassword;
	EditText edittxtbatch;
	EditText editTxtCourse;
	EditText editBranch;
	EditText editTxtRegisterno;
	EditText edittxtCollegeName;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.usercreationactivity);
		
		butsaveUser=(Button) findViewById(R.id.but_createUser);		
		editTxtUserName = (EditText) findViewById(R.id.editTxtUserName);
		editTxtparentpassword = (EditText) findViewById(R.id.editTxtuserpassword);
		edittxtbatch = (EditText) findViewById(R.id.edittxtbatch);
		editTxtCourse = (EditText) findViewById(R.id.editTxtCourse);
		editBranch = (EditText) findViewById(R.id.editBranch);
		editTxtRegisterno = (EditText) findViewById(R.id.editTxtRegisterno);
		edittxtCollegeName = (EditText) findViewById(R.id.edittxtCollegeName);
		
		
		butsaveUser.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				saveUser();			
				
			}
		});
		
		
		
	}
	
	
	
	private void saveUser(){
		
		
		try{
			ParseUser objuser=new ParseUser();
			
			objuser.setUsername(editTxtUserName.getText().toString());
			objuser.setPassword(editTxtparentpassword.getText().toString());
			objuser.put("batch",edittxtbatch.getText().toString());
			objuser.put("branch",editBranch.getText().toString());
			objuser.put("course",editTxtCourse.getText().toString());
			objuser.put("usertype","student");
			objuser.put("registerno",editTxtRegisterno.getText().toString());
			objuser.put("college",edittxtCollegeName.getText().toString());
			setProgressBarIndeterminateVisibility(true);
			objuser.signUpInBackground(new SignUpCallback() {
				@Override
				public void done(ParseException e) {
					setProgressBarIndeterminateVisibility(false);
					
					if (e == null) {
						// Success!
						Toast.makeText(getApplicationContext(), "User Created", Toast.LENGTH_LONG).show();
					}
					else {
						Toast.makeText(getApplicationContext(),
								"User Creation Failed",
								Toast.LENGTH_LONG).show();
					}
				}
			});
			
			Toast.makeText(getApplicationContext(), "User Created", Toast.LENGTH_LONG).show();
		}catch(Exception ex){
			Toast.makeText(getApplicationContext(),
					"User Creation Failed",
					Toast.LENGTH_LONG).show();
		}
		
	}
	
	

}

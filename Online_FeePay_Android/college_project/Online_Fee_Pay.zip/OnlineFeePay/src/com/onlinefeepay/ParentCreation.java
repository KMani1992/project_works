package com.onlinefeepay;


import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SaveCallback;
import com.parse.SignUpCallback;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ParentCreation extends Activity{
	
	
	Button butSaveParent;
	EditText editTxtParentName;
	EditText editTxtparentpassword;
	EditText editTxtstudRegisterNo;
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.parentcreation);
		
		
		editTxtParentName = (EditText) findViewById(R.id.editTxtParentName);
		editTxtparentpassword = (EditText) findViewById(R.id.editTxtparentpassword);
		editTxtstudRegisterNo = (EditText) findViewById(R.id.editTxtstudRegisterNo);
		
		butSaveParent=(Button) findViewById(R.id.butSaveParent);
		
		butSaveParent.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				
				ParseUser objparent=new ParseUser();
				
				
				objparent.setUsername(editTxtParentName.getText().toString());
				objparent.setPassword(editTxtparentpassword.getText().toString());
				objparent.put("usertype","parent");
				objparent.put("registerno",editTxtstudRegisterNo.getText().toString());
				
				setProgressBarIndeterminateVisibility(true);
				
				objparent.signUpInBackground(new SignUpCallback() {
					@Override
					public void done(ParseException e) {
						setProgressBarIndeterminateVisibility(false);
						
						if (e == null) {
							// Success!
							Toast.makeText(getApplicationContext(), "Parent Created", Toast.LENGTH_LONG).show();
						}
						else {
							Toast.makeText(getApplicationContext(),
									"Parent Creation Failed",
									Toast.LENGTH_LONG).show();
						}
					}
				});
		
			}
		
	});
		
	}
}

package com.onlinefeepay;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import android.app.Activity;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TwoLineListItem;

public class StatusView  extends Activity{
	
	
	Button but_gen_exam_fee_cirul;
	Button but_genfee_all;
	
	EditText edittxtfeeID;
	String id;
	String amount;
	List<UserList> userlist=null;
	List<ParseObject> ob;
	ListView lstv;
	String accno="HDFC - 86361010003264";
	String regnogl="1234";
	
	
	ProgressDialog mProgressDialog;
	//ArrayAdapter<String> adaptera;
	//ArrayAdapter<String> adapter ;
	//ArrayAdapter<String> adapter;
	
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.viewstatus);
		
		lstv = (ListView) findViewById(R.id.listviewstatus);
		
		
		
		
		
		//refreshUserList();
		//new RemoteDataTask().execute();
		ref();
		//refreshPostList();
		
		
		
		
		
		
		lstv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> parentAdapter, View view,
					int position, long id) {
				if(Util.isStudent){
				ParseQuery<ParseObject> query = ParseQuery.getQuery("examfee");
				
				//query.whereEqualTo("feeid", edittxtfeeID.getText().toString());
		
				String []valuelst=((TextView)view).getText().toString().split(",");
				
				GetSet.setSem(valuelst[1]);
				GetSet.setMonth(valuelst[2]);
				GetSet.setAmount(valuelst[3]);
				GetSet.setAccno(accno);
				GetSet.setRegNo(regnogl);
				GetSet.setObjId(valuelst[5]);
				
				Intent intent = new Intent(
						StatusView.this,
						FeePay.class);
				startActivity(intent);
				
				
				}
				return false;
			}
		
			});
	}
	
	
	private void refreshPostList() {

		ParseQuery<ParseObject> query = ParseQuery.getQuery("examfee");
		//query.whereEqualTo("author", ParseUser.getCurrentUser());

		setProgressBarIndeterminateVisibility(true);

		
final List<String> val=new ArrayList<String>();
		
		// Pass the results into an ArrayAdapter
		//ArrayAdapter<String> adapter = new ArrayAdapter<String>(CircularGenerate.this, android.R.layout.simple_list_item_1,android.R.id.text1,val);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(StatusView.this, android.R.layout.simple_list_item_1,android.R.id.text1,val);
		
		
		
		userlist = new ArrayList<UserList>();
		
		userlist.clear();
		val.clear();
		
		
		query.findInBackground(new FindCallback<ParseObject>() {

			@SuppressWarnings("unchecked")
			@Override
			public void done(List<ParseObject> postList, ParseException e) {
				setProgressBarIndeterminateVisibility(false);
				if (e == null) {
					// If there are results, update the list of posts
					// and notify the adapter
					//posts.clear();
					for (ParseObject obj : postList) {
//						Note note = new Note(post.getObjectId(), post
//								.getString("title"), post.getString("content"));
//						posts.add(note);
						
						
						
						String amountlo =obj.getString("amount");
						String semester=obj.getString("semester");
						String monyr=obj.getString("monyr");
						String status="Not Paid";
						status= obj.getString("status");
						regnogl=obj.getString("studregno");
						
						
						val.add(semester +  " sem," + monyr + ",Rs " + amountlo + ", " + status);
						
						
					}
//					((ArrayAdapter<Note>) getListAdapter())
//							.notifyDataSetChanged();
					
					
				} else {

					Log.d(getClass().getSimpleName(), "Error: " + e.getMessage());
				}

			}

		});

		
		lstv.setAdapter(adapter);
		
	}

private void ref(){
		
		Toast.makeText(getApplicationContext(), "Loading ...Please Wait", Toast.LENGTH_SHORT).show();
		
//		ParseQuery<ParseObject> query = new ParseQuery<ParseObject>(
//				"examfee");
		
		ParseQuery<ParseObject> query = ParseQuery.getQuery("examfee");
		
		if(Util.isStudent || Util.isParent){
			query.whereEqualTo("studregno", Util.studRegNo);
		}
		
		//query.whereEqualTo("course", "cse");
		
		
		
		// Locate the listview in listview_main.xml
		//lstv = (ListView) findViewById(R.id.listviewcir);
		//String []value= String ();
		
		
		final List<String> val=new ArrayList<String>();
		
		// Pass the results into an ArrayAdapter
		//ArrayAdapter<String> adapter = new ArrayAdapter<String>(CircularGenerate.this, android.R.layout.simple_list_item_1,android.R.id.text1,val);
		final ArrayAdapter<String> adapter = new ArrayAdapter<String>(StatusView.this, android.R.layout.simple_list_item_1,android.R.id.text1,val);
		
		
		
		userlist = new ArrayList<UserList>();
		
		userlist.clear();
		val.clear();
		
		//final String regno="";
		
		query.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> objects, ParseException e) {
				// TODO Auto-generated method stub
				
				//Toast.makeText(getApplicationContext(), "top " + objects.size(), Toast.LENGTH_SHORT).show();
				
				if(e==null){
				
					Toast.makeText(getApplicationContext(), "Success" , Toast.LENGTH_SHORT).show();
					ParseObject obj;
					
				for (int i=0;i<objects.size();i++){
						obj=objects.get(i);
				
						
				
				String amountlo =obj.getString("amount");
				String semester=obj.getString("semester");
				String monyr=obj.getString("monyr");
				String status="Not Paid";
				status= obj.getString("status");
				regnogl=obj.getString("studregno");
				
				if(status==null){
					status="Not Paid";
				}
				if(regnogl!=null){
				val.add(regnogl + ", " + semester +  " sem," + monyr + ",Rs " + amountlo + ", " + status + ", " + obj.getObjectId());
				}
				
				
				
				}
				
				lstv.setAdapter(adapter);
				
				Toast.makeText(getApplicationContext(), "Loaded", Toast.LENGTH_SHORT).show();
				
				}else{
					Toast.makeText(getApplicationContext(), "Fail to Load", Toast.LENGTH_SHORT).show();	
				}
				
			}
		});
		
		
		if(val.size()==0){
//			val.add("4 sem,Mar-2016,Rs 1200,Not Paid");
//			val.add("3 sem,Nov-2015,Rs 1200,Not Paid");
//			val.add("2 sem,Mar-2015,Rs 1400,Not Paid");
//			val.add("1 sem,Nov-2014,Rs 1400,Not Paid");
			val.add("1234,4 sem,Mar-2016,Rs 1200,Not Paid,I0");
			val.add("1235,3 sem,Nov-2015,Rs 1200,Not Paid,I1");
			val.add("1236,2 sem,Mar-2015,Rs 1400,Not Paid,I2");
			val.add("1237,1 sem,Nov-2014,Rs 1400,Not Paid,I3");
			
			lstv.setAdapter(adapter);
		}
		
		ParseQuery<ParseObject> query1 = new ParseQuery<ParseObject>(
				"bankacc");
				
		//Toast.makeText(getApplicationContext(), "Fid " + edittxtfeeID.getText().toString(), Toast.LENGTH_SHORT).show();
		
		if(regnogl!=""){		
			
			query1.whereEqualTo("studregno", regnogl);
			
		}
				
				
				
				query1.findInBackground(new FindCallback<ParseObject>() {

					@Override
					public void done(List<ParseObject> objects, ParseException e) {
						// TODO Auto-generated method stub
						
						//Toast.makeText(getApplicationContext(), "top " + objects.size(), Toast.LENGTH_SHORT).show();
						
						if(e==null){
						
							//Toast.makeText(getApplicationContext(), "Fsi" + objects.size(), Toast.LENGTH_SHORT).show();
							
						if(objects.size()>0){
							ParseObject objf=objects.get(0);
							accno=objf.getString("bankname") + " - " + objf.getString("accountno");
						
						
						}
						
						}else{
							Toast.makeText(getApplicationContext(), "Fail to Load", Toast.LENGTH_SHORT).show();	
						}
						
					}
				});
		
//		
//		
		
//		
//		val.add("Barani,2 Yr,3rd sem");
//		val.add("Malar,2 Yr,3rd sem");
//		val.add("Mani,2 Yr,3rd sem");
//		val.add("Raja,2 Yr,3rd sem");
//		val.add("Raju,2 Yr,3rd sem");
//		val.add("Viji,2 Yr,3rd sem");			
//		
		
		
		
		
//		for (ParseObject post : ob) {
//			UserList note = new UserList(post.getObjectId(), 
//					post.getString("registerno"), post.getString("username"),post.getString("course"),post.getString("branch"),post.getString("batch"));
//			userlist.add(note);
//		}
	
		// Binds the Adapter to the ListView
		
		
		// Close the progressdialog
		//mProgressDialog.dismiss();
		
		
		
		
		
		
		
		//qry.findInBackground(new FindCallback<ParseObject>() {

		//	@Override
//			public void done(List<ParseObject> objects, ParseException e) {
//				// TODO Auto-generated method stub
//				
//				if (e==null){
//					
//					Toast.makeText(getApplicationContext(), "Success", Toast.LENGTH_SHORT).show();
//					String a = null;
//					ParseObject obj;
//					
//					for (int i=0;i<objects.size();i++){
//						obj=objects.get(i);
//						
//						a +=   obj.getString("branch");
//						
//					}
//					
//					Toast.makeText(getApplicationContext(), a, Toast.LENGTH_SHORT).show();
//					
//				}else{
//					
//					Toast.makeText(getApplicationContext(), "Fail", Toast.LENGTH_SHORT).show();
//					
//				}
//				
//			}
//			
//			
//		});
		
	}
	
		
	
	
	// RemoteDataTask AsyncTask
		private class RemoteDataTask extends AsyncTask<Void, Void, Void> {
			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				// Create a progressdialog
				mProgressDialog = new ProgressDialog(StatusView.this);
				// Set progressdialog title
				mProgressDialog.setTitle("Fetching Status Info");
				// Set progressdialog message
				mProgressDialog.setMessage("Loading...");
				mProgressDialog.setIndeterminate(false);
				// Show progressdialog
				mProgressDialog.show();
			}

			@Override
			protected Void doInBackground(Void... params) {
				// Locate the class table named "Country" in Parse.com
				ParseQuery<ParseObject> query = new ParseQuery<ParseObject>(
						"user");
				//query.orderByDescending("_created_at");
				try {
					query.whereEqualTo("usertype", "student");
					ob = query.find();
				} catch (ParseException e) {
					Log.e("Error", e.getMessage());
					e.printStackTrace();
				}
				return null;
			}

			@Override
			protected void onPostExecute(Void result) {
				// Locate the listview in listview_main.xml
				
				//String []value= String ();
				
				
				List<String> val=new ArrayList<String>();
				
				// Pass the results into an ArrayAdapter
				ArrayAdapter<String> adapter = new ArrayAdapter<String>(StatusView.this, android.R.layout.simple_list_item_1,android.R.id.text1,val);
				
				
				
				userlist = new ArrayList<UserList>();
				
				userlist.clear();
				
				// Retrieve object "name" from Parse.com database
				for (ParseObject user : ob) {
					//adapter.add((String) country.get("name"));
					val.add((String) user.get("username"));
				}
				
				
				val.add("1234,4 sem,Mar-2016,Rs 1200,Not Paid,I0");
				val.add("1235,3 sem,Nov-2015,Rs 1200,Not Paid,I1");
				val.add("1236,2 sem,Mar-2015,Rs 1400,Not Paid,I2");
				val.add("1237,1 sem,Nov-2014,Rs 1400,Not Paid,I3");

			
				// Binds the Adapter to the ListView
				lstv.setAdapter(adapter);
				
				// Close the progressdialog
				mProgressDialog.dismiss();
				
				
			}
		}
	
		
		
		
		

		
	
}
